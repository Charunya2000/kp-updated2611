﻿# efs-s-x12

Generated npm-style bundle from efs-s ClojureScript output.

## Build source project

1. Run mvn -q compile in the source repo.
2. Run powershell -ExecutionPolicy Bypass -File scripts/build-npm-lib.ps1.

## Use from another Node.js repo

Copy this folder or run 
pm pack here and install the tarball.

The packaged bundle includes a default lookup spec at:

save/companion-db-lookups.edn

Install peer dependency:

`ash
npm install oracledb@6.8.0
`

`js
const x12 = require("efs-s-x12");
const result = x12.parseX12Full("src/main/resources/edisamples/test1.txt");
console.log(result);
`
