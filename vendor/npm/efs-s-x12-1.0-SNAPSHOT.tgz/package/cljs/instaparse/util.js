// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('instaparse.util');
goog.require('cljs.core');
instaparse.util.throw_runtime_exception = (function instaparse$util$throw_runtime_exception(var_args){
var args__5882__auto__ = [];
var len__5876__auto___531 = arguments.length;
var i__5877__auto___532 = (0);
while(true){
if((i__5877__auto___532 < len__5876__auto___531)){
args__5882__auto__.push((arguments[i__5877__auto___532]));

var G__533 = (i__5877__auto___532 + (1));
i__5877__auto___532 = G__533;
continue;
} else {
}
break;
}

var argseq__5883__auto__ = ((((0) < args__5882__auto__.length))?(new cljs.core.IndexedSeq(args__5882__auto__.slice((0)),(0),null)):null);
return instaparse.util.throw_runtime_exception.cljs$core$IFn$_invoke$arity$variadic(argseq__5883__auto__);
});

(instaparse.util.throw_runtime_exception.cljs$core$IFn$_invoke$arity$variadic = (function (message){
var text = cljs.core.apply.call(null,cljs.core.str,message);
throw text;
}));

(instaparse.util.throw_runtime_exception.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(instaparse.util.throw_runtime_exception.cljs$lang$applyTo = (function (seq530){
var self__5862__auto__ = this;
return self__5862__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq530));
}));

instaparse.util.throw_illegal_argument_exception = (function instaparse$util$throw_illegal_argument_exception(var_args){
var args__5882__auto__ = [];
var len__5876__auto___535 = arguments.length;
var i__5877__auto___536 = (0);
while(true){
if((i__5877__auto___536 < len__5876__auto___535)){
args__5882__auto__.push((arguments[i__5877__auto___536]));

var G__537 = (i__5877__auto___536 + (1));
i__5877__auto___536 = G__537;
continue;
} else {
}
break;
}

var argseq__5883__auto__ = ((((0) < args__5882__auto__.length))?(new cljs.core.IndexedSeq(args__5882__auto__.slice((0)),(0),null)):null);
return instaparse.util.throw_illegal_argument_exception.cljs$core$IFn$_invoke$arity$variadic(argseq__5883__auto__);
});

(instaparse.util.throw_illegal_argument_exception.cljs$core$IFn$_invoke$arity$variadic = (function (message){
var text = cljs.core.apply.call(null,cljs.core.str,message);
throw text;
}));

(instaparse.util.throw_illegal_argument_exception.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(instaparse.util.throw_illegal_argument_exception.cljs$lang$applyTo = (function (seq534){
var self__5862__auto__ = this;
return self__5862__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq534));
}));

instaparse.util.regexp_flags = (function instaparse$util$regexp_flags(re){
var G__538 = "";
var G__538__$1 = (cljs.core.truth_(re.ignoreCase)?(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__538)+"i"):G__538);
var G__538__$2 = (cljs.core.truth_(re.multiline)?(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__538__$1)+"m"):G__538__$1);
if(cljs.core.truth_(re.unicode)){
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__538__$2)+"u");
} else {
return G__538__$2;
}
});

//# sourceMappingURL=util.js.map
