// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('instaparse.failure');
goog.require('cljs.core');
goog.require('instaparse.print');
/**
 * Takes an index into text, and determines the line and column info
 */
instaparse.failure.index__GT_line_column = (function instaparse$failure$index__GT_line_column(index,text){
var line = (1);
var col = (1);
var counter = (0);
while(true){
if(cljs.core._EQ_.call(null,index,counter)){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"line","line",212345235),line,new cljs.core.Keyword(null,"column","column",2078222095),col], null);
} else {
if(cljs.core._EQ_.call(null,"\n",cljs.core.get.call(null,text,counter))){
var G__1034 = (line + (1));
var G__1035 = (1);
var G__1036 = (counter + (1));
line = G__1034;
col = G__1035;
counter = G__1036;
continue;
} else {
var G__1037 = line;
var G__1038 = (col + (1));
var G__1039 = (counter + (1));
line = G__1037;
col = G__1038;
counter = G__1039;
continue;

}
}
break;
}
});
instaparse.failure.get_line = (function instaparse$failure$get_line(n,text){
var chars = cljs.core.seq.call(null,clojure.string.replace.call(null,text,"\r\n","\n"));
var n__$1 = n;
while(true){
if(cljs.core.empty_QMARK_.call(null,chars)){
return "";
} else {
if(cljs.core._EQ_.call(null,n__$1,(1))){
return cljs.core.apply.call(null,cljs.core.str,cljs.core.take_while.call(null,cljs.core.complement.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["\n",null], null), null)),chars));
} else {
if(cljs.core._EQ_.call(null,"\n",cljs.core.first.call(null,chars))){
var G__1040 = cljs.core.next.call(null,chars);
var G__1041 = (n__$1 - (1));
chars = G__1040;
n__$1 = G__1041;
continue;
} else {
var G__1042 = cljs.core.next.call(null,chars);
var G__1043 = n__$1;
chars = G__1042;
n__$1 = G__1043;
continue;

}
}
}
break;
}
});
/**
 * Creates string with caret at nth position, 1-based
 * and accounts for horizontal tabs which might change
 * the alignment of the '^' to the error location.
 */
instaparse.failure.marker = (function instaparse$failure$marker(text,n){
if(cljs.core.truth_((function (){var and__5140__auto__ = text;
if(cljs.core.truth_(and__5140__auto__)){
return cljs.core.integer_QMARK_.call(null,n);
} else {
return and__5140__auto__;
}
})())){
var marker_text = clojure.string.replace.call(null,text,/[^\s]/," ");
if((n <= (1))){
return "^";
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.subs.call(null,marker_text,(0),(n - (1))))+cljs.core.str.cljs$core$IFn$_invoke$arity$1("^"));
}
} else {
return null;
}
});
/**
 * Adds text, line, and column info to failure object.
 */
instaparse.failure.augment_failure = (function instaparse$failure$augment_failure(failure,text){
var lc = instaparse.failure.index__GT_line_column.call(null,new cljs.core.Keyword(null,"index","index",-1531685915).cljs$core$IFn$_invoke$arity$1(failure),text);
return cljs.core.merge.call(null,failure,lc,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"text","text",-1790561697),instaparse.failure.get_line.call(null,new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(lc),text)], null));
});
/**
 * Provides special case for printing negative lookahead reasons
 */
instaparse.failure.print_reason = (function instaparse$failure$print_reason(r){
if(cljs.core.truth_(new cljs.core.Keyword(null,"NOT","NOT",-1689245341).cljs$core$IFn$_invoke$arity$1(r))){
cljs.core.print.call(null,"NOT ");

return cljs.core.print.call(null,new cljs.core.Keyword(null,"NOT","NOT",-1689245341).cljs$core$IFn$_invoke$arity$1(r));
} else {
if(cljs.core.truth_(new cljs.core.Keyword(null,"char-range","char-range",1443391389).cljs$core$IFn$_invoke$arity$1(r))){
return cljs.core.print.call(null,instaparse.print.char_range__GT_str.call(null,r));
} else {
if((r instanceof RegExp)){
return cljs.core.print.call(null,instaparse.print.regexp__GT_str.call(null,r));
} else {
return cljs.core.pr.call(null,r);

}
}
}
});
/**
 * Takes an augmented failure object and prints the error message
 */
instaparse.failure.pprint_failure = (function instaparse$failure$pprint_failure(p__1044){
var map__1045 = p__1044;
var map__1045__$1 = cljs.core.__destructure_map.call(null,map__1045);
var line = cljs.core.get.call(null,map__1045__$1,new cljs.core.Keyword(null,"line","line",212345235));
var column = cljs.core.get.call(null,map__1045__$1,new cljs.core.Keyword(null,"column","column",2078222095));
var text = cljs.core.get.call(null,map__1045__$1,new cljs.core.Keyword(null,"text","text",-1790561697));
var reason = cljs.core.get.call(null,map__1045__$1,new cljs.core.Keyword(null,"reason","reason",-2070751759));
cljs.core.println.call(null,(""+"Parse error at line "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(line)+", column "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+":"));

cljs.core.println.call(null,text);

cljs.core.println.call(null,instaparse.failure.marker.call(null,text,column));

var full_reasons = cljs.core.distinct.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"expecting","expecting",-57706705),cljs.core.filter.call(null,new cljs.core.Keyword(null,"full","full",436801220),reason)));
var partial_reasons = cljs.core.distinct.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"expecting","expecting",-57706705),cljs.core.filter.call(null,cljs.core.complement.call(null,new cljs.core.Keyword(null,"full","full",436801220)),reason)));
var total = (cljs.core.count.call(null,full_reasons) + cljs.core.count.call(null,partial_reasons));
if((total === (0))){
} else {
if(cljs.core._EQ_.call(null,(1),total)){
cljs.core.println.call(null,"Expected:");
} else {
cljs.core.println.call(null,"Expected one of:");

}
}

var seq__1046_1054 = cljs.core.seq.call(null,full_reasons);
var chunk__1047_1055 = null;
var count__1048_1056 = (0);
var i__1049_1057 = (0);
while(true){
if((i__1049_1057 < count__1048_1056)){
var r_1058 = cljs.core._nth.call(null,chunk__1047_1055,i__1049_1057);
instaparse.failure.print_reason.call(null,r_1058);

cljs.core.println.call(null," (followed by end-of-string)");


var G__1059 = seq__1046_1054;
var G__1060 = chunk__1047_1055;
var G__1061 = count__1048_1056;
var G__1062 = (i__1049_1057 + (1));
seq__1046_1054 = G__1059;
chunk__1047_1055 = G__1060;
count__1048_1056 = G__1061;
i__1049_1057 = G__1062;
continue;
} else {
var temp__5825__auto___1063 = cljs.core.seq.call(null,seq__1046_1054);
if(temp__5825__auto___1063){
var seq__1046_1064__$1 = temp__5825__auto___1063;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__1046_1064__$1)){
var c__5673__auto___1065 = cljs.core.chunk_first.call(null,seq__1046_1064__$1);
var G__1066 = cljs.core.chunk_rest.call(null,seq__1046_1064__$1);
var G__1067 = c__5673__auto___1065;
var G__1068 = cljs.core.count.call(null,c__5673__auto___1065);
var G__1069 = (0);
seq__1046_1054 = G__1066;
chunk__1047_1055 = G__1067;
count__1048_1056 = G__1068;
i__1049_1057 = G__1069;
continue;
} else {
var r_1070 = cljs.core.first.call(null,seq__1046_1064__$1);
instaparse.failure.print_reason.call(null,r_1070);

cljs.core.println.call(null," (followed by end-of-string)");


var G__1071 = cljs.core.next.call(null,seq__1046_1064__$1);
var G__1072 = null;
var G__1073 = (0);
var G__1074 = (0);
seq__1046_1054 = G__1071;
chunk__1047_1055 = G__1072;
count__1048_1056 = G__1073;
i__1049_1057 = G__1074;
continue;
}
} else {
}
}
break;
}

var seq__1050 = cljs.core.seq.call(null,partial_reasons);
var chunk__1051 = null;
var count__1052 = (0);
var i__1053 = (0);
while(true){
if((i__1053 < count__1052)){
var r = cljs.core._nth.call(null,chunk__1051,i__1053);
instaparse.failure.print_reason.call(null,r);

cljs.core.println.call(null);


var G__1075 = seq__1050;
var G__1076 = chunk__1051;
var G__1077 = count__1052;
var G__1078 = (i__1053 + (1));
seq__1050 = G__1075;
chunk__1051 = G__1076;
count__1052 = G__1077;
i__1053 = G__1078;
continue;
} else {
var temp__5825__auto__ = cljs.core.seq.call(null,seq__1050);
if(temp__5825__auto__){
var seq__1050__$1 = temp__5825__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__1050__$1)){
var c__5673__auto__ = cljs.core.chunk_first.call(null,seq__1050__$1);
var G__1079 = cljs.core.chunk_rest.call(null,seq__1050__$1);
var G__1080 = c__5673__auto__;
var G__1081 = cljs.core.count.call(null,c__5673__auto__);
var G__1082 = (0);
seq__1050 = G__1079;
chunk__1051 = G__1080;
count__1052 = G__1081;
i__1053 = G__1082;
continue;
} else {
var r = cljs.core.first.call(null,seq__1050__$1);
instaparse.failure.print_reason.call(null,r);

cljs.core.println.call(null);


var G__1083 = cljs.core.next.call(null,seq__1050__$1);
var G__1084 = null;
var G__1085 = (0);
var G__1086 = (0);
seq__1050 = G__1083;
chunk__1051 = G__1084;
count__1052 = G__1085;
i__1053 = G__1086;
continue;
}
} else {
return null;
}
}
break;
}
});

//# sourceMappingURL=failure.js.map
