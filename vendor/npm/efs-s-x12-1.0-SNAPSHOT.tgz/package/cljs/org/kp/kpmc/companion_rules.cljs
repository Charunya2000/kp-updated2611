(ns org.kp.kpmc.companion-rules
  (:require [cljs.reader :as reader]
            [clojure.string :as str]
            [org.kp.kpmc.companion :as companion]
            [org.kp.kpmc.io-node :as io]
            [org.kp.kpmc.parser :as parser]))

(defn- blankish? [s]
  (or (nil? s) (str/blank? (str s))))

(defn- tag-name [x]
  (cond
    (keyword? x) (name x)
    (string? x) x
    :else (str x)))

(defn- tag= [node t]
  (and (sequential? node)
       (= (tag-name (first node)) t)))

(defn- normalize-usage [raw]
  (let [v (str/trim (or raw ""))]
    (case v
      "R" :required
      "S" :situational
      "Not Used" :not-used
      :unknown)))

(defn- zero-pad2 [n]
  (if (< n 10) (str "0" n) (str n)))

(defn parse-companion-csv->model
  "Parse companion guide CSV into a rich model with legend, loops, and rows.
   Handles continuation option rows where cols A/B are blank."
  [csv-text]
  (let [rows (->> csv-text
                  companion/join-multiline-quoted-fields
                  (map companion/parse-csv-line)
                  (map #(vec (concat % (repeat 5 ""))))
                  (map #(subvec % 0 5))
                  vec)
        header-idx (first (keep-indexed
                           (fn [idx row]
                             (when (= "Ref. Des." (str/trim (nth row 1 ""))) idx))
                           rows))
        legend-rows (if header-idx (subvec rows 0 header-idx) [])
        body-rows (if header-idx (subvec rows (inc header-idx)) [])
        legend-start (first (keep-indexed
                             (fn [idx row]
                               (when (= "Legend" (str/trim (nth row 0 ""))) idx))
                             legend-rows))
        legend-pairs
        (if (nil? legend-start)
          []
          (->> (subvec legend-rows (inc legend-start))
               (map (fn [row]
                      [(str/trim (nth row 0 ""))
                       (str/trim (nth row 1 ""))]))
               (filter (fn [[k v]] (or (not (blankish? k)) (not (blankish? v)))))
               (map (fn [[k v]] {:key k :value v}))
               vec))]
    (loop [remaining body-rows
           current-loop nil
           current-element nil
           loops []
           elements []]
      (if (empty? remaining)
        {:legend legend-pairs
         :loops loops
         :elements (cond-> elements current-element (conj current-element))}
        (let [[col-a col-b col-c col-d col-e] (first remaining)
              a (str/trim col-a)
              b (str/trim col-b)
              c (str/trim col-c)
              d (str/trim col-d)
              e (str/trim col-e)
              loop-line? (str/starts-with? a "Loop:")
              ref-row? (not (blankish? b))
              cont-option-row? (and (blankish? a)
                                    (blankish? b)
                                    (not (blankish? d))
                                    (not (nil? current-element)))]
          (cond
            loop-line?
            (let [next-loop (companion/parse-loop-header a)]
              (recur (rest remaining)
                     next-loop
                     current-element
                     (if next-loop (conj loops next-loop) loops)
                     elements))

            ref-row?
            (let [next-element {:loop current-loop
                                :label a
                                :segment-ref b
                                :usage (normalize-usage c)
                                :kp-element d
                                :element-description e
                                :options []}]
              (recur (rest remaining)
                     current-loop
                     next-element
                     loops
                     (cond-> elements current-element (conj current-element))))

            cont-option-row?
            (let [opt {:usage (normalize-usage c)
                       :kp-element d
                       :element-description e}]
              (recur (rest remaining)
                     current-loop
                     (update current-element :options conj opt)
                     loops
                     elements))

            :else
            (recur (rest remaining)
                   current-loop
                   current-element
                   loops
                   elements)))))))

(defn- parse-length-limit [desc]
  (when-let [m (re-find #"(?i)up to\s+(\d+)\s+bytes" (or desc ""))]
    (js/parseInt (second m) 10)))

(defn- split-options [s]
  (let [norm (-> (or s "")
                 (str/replace #"\s+or\s+" ",")
                 (str/replace #"\bor\b" ","))]
    (->> (str/split norm #",")
         (map str/trim)
         (remove blankish?)
         vec)))

(defn- placeholder-kind [kp]
  (cond
    (= kp "<Blank>") :blank
    (= kp "<YYMMDD>") :yymmdd
    (= kp "<CCYYMMDD>") :ccyymmdd
    (= kp "<HHMM>") :hhmm
    (= kp "<HHMMSS>") :hhmmss
    (= kp "<HHMMSSDD>") :hhmmssdd
    (= kp "<Number>") :number
    (= kp "<Unique Number>") :unique-number
    (= kp "<Area Code><Phone>") :phone10
    (= kp "<Subscriber SSN>") :ssn
    (= kp "Subscriber SSN") :ssn
    (= kp "XXXXXXXXXXXXXXX") :x-mask
    (= kp "<All Possible Codes>") :all-possible-codes
    (= kp "All values") :all-values
    :else nil))

(defn- all-values-336-rule?
  "Special companion guide case: 'All Values,336(Hire Date)' means value must be 336."
  [kp]
  (boolean (re-matches #"(?i)\s*All\s+Values\s*,\s*336(?:\s*\(.*\))?\s*" (or kp ""))))

(defn- enum-valid?
  "For enum rules, required fields must match allowed values; optional fields may be blank."
  [usage allowed-values value]
  (let [v (str/trim (or value ""))
        allowed? (contains? allowed-values v)]
    (if (= usage :required)
      allowed?
      (or (blankish? v) allowed?))))

(defn- hd01-rule?
  "Detect the HD01 companion rule that is conditioned by BGN08 values."
  [rule]
  (and (= "HD01" (:segment-ref rule))
       (= "001, 021, 024, 030" (str/trim (or (:kp-element rule) "")))))

(defn- hd01-allowed-by-bgn08
  "Allowed HD01 values based on captured BGN08 action code.
   BGN08=2 => 001/021/024, BGN08=4 or RX => 030.
   If BGN08 is unavailable, keep permissive base set."
  [context]
  (let [bgn08 (str/trim (or (get context "BGN08") ""))]
    (cond
      (= bgn08 "2") #{"001" "021" "024"}
      (or (= bgn08 "4") (= bgn08 "RX")) #{"030"}
      :else #{"001" "021" "024" "030"})))

(defn- external-ref-token?
  "True for angle-bracket tokens that represent external references, e.g. <Fed Tax Id>."
  [kp]
  (boolean (re-matches #"^<[^>]+>$" (or kp ""))))

(defn- contains-angle-token?
  "True when a KP element expression contains any angle-bracket token text."
  [kp]
  (boolean (re-find #"[<>]" (or kp ""))))

(defn- build-rule-predicate [rule]
  (let [kp (:kp-element rule)
        desc (:element-description rule)
        p-kind (placeholder-kind kp)
        ref-match (re-find #"^<Same as\s+([A-Z0-9]{2,3}[0-9]{2})>$" kp)
        option-values (->> (concat [kp] (map :kp-element (:options rule)))
                           (map str/trim)
                           (mapcat split-options)
                           (remove blankish?)
                           (remove #(= % "<Blank>"))
                           (remove external-ref-token?)
                           distinct
                           vec)
        x-max-len (parse-length-limit desc)]
    (cond
      ref-match
      {:kind :cross-ref
       :validate (fn [{:keys [value context]}]
                   (let [ref (second ref-match)
                         expected (get context ref)]
                     (if (blankish? expected)
                       {:valid true :note :missing-reference-context}
                       {:valid (= (str value) (str expected))
                        :expected expected
                        :actual value}))) }

      (= p-kind :blank)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (blankish? value)})}

      (= p-kind :yymmdd)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{6}" (or value "")))})}

      (= p-kind :ccyymmdd)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{8}" (or value "")))})}

      (= p-kind :hhmm)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{4}" (or value "")))})}

      (= p-kind :hhmmss)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{6}" (or value "")))})}

      (= p-kind :hhmmssdd)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{6,8}" (or value "")))})}

      (or (= p-kind :number) (= p-kind :unique-number))
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d+" (or value "")))})}

      (= p-kind :phone10)
      {:kind :placeholder
       :validate (fn [{:keys [value]}] {:valid (boolean (re-matches #"\d{10}" (or value "")))})}

      (= p-kind :ssn)
      {:kind :placeholder
       :validate (fn [{:keys [value]}]
                   {:valid (or (blankish? value)
                               (boolean (re-matches #"\d{9}" (or value ""))))})}

      (= p-kind :x-mask)
      {:kind :pattern-hint
       :validate (fn [{:keys [value]}]
                   {:valid (if x-max-len
                             (<= (count (or value "")) x-max-len)
                             (not (blankish? value)))})}

      (= p-kind :all-values)
      {:kind :open
       :validate (fn [_] {:valid true})}

      (all-values-336-rule? kp)
      {:kind :enum
       :allowed #{"336"}
       :validate (fn [{:keys [value]}]
           {:valid (enum-valid? (:usage rule) #{"336"} value)
            :allowed ["336"]})}

      (= p-kind :all-possible-codes)
      {:kind :external-code-list
        :validate (fn [{:keys [value]}]
               {:valid (if (= (:usage rule) :required)
               (not (blankish? value))
               true)
                :note :external-code-list})}

      (hd01-rule? rule)
      {:kind :enum
       :allowed #{"001" "021" "024" "030"}
       :validate (fn [{:keys [value context]}]
                   (let [allowed (hd01-allowed-by-bgn08 context)]
                     {:valid (enum-valid? (:usage rule) allowed value)
                      :allowed (vec allowed)
                      :based-on {:BGN08 (get context "BGN08")}}))}

       (and (contains-angle-token? kp)
         (str/includes? kp "<Blank>")
         (seq option-values))
       {:kind :enum
        :allowed (set option-values)
        :validate (fn [{:keys [value]}]
              {:valid (or (blankish? value)
                 (contains? (set option-values) (str/trim (or value ""))))
            :allowed (vec (concat ["<Blank>"] option-values))})}

       (and (nil? p-kind)
         (nil? ref-match)
         (contains-angle-token? kp))
       {:kind :placeholder
        :validate (fn [{:keys [value]}]
              (if (= (:usage rule) :required)
             {:valid (not (blankish? value)) :expected :non-blank}
             {:valid true}))}

      (seq option-values)
      {:kind :enum
       :allowed (set option-values)
       :validate (fn [{:keys [value]}]
                   {:valid (enum-valid? (:usage rule) (set option-values) value)
                    :allowed option-values})}

      :else
      {:kind :literal
       :validate (fn [{:keys [value]}] {:valid (= (str/trim (or value "")) kp) :expected kp})})))

(defn compile-rules
  "Compile parsed companion model rows into executable rule maps with cljs predicates."
  [model]
  (->> (:elements model)
       (map (fn [e]
              (let [{:keys [segment-id position]} (or (companion/parse-segment-ref (:segment-ref e)) {})
                    pred (build-rule-predicate e)]
                (merge
                 {:rule-id (str (or segment-id "UNK") (or (zero-pad2 (or position 0)) "00"))
                  :segment-id segment-id
                  :position position
                  :usage (:usage e)
                  :segment-ref (:segment-ref e)
                  :label (:label e)
                  :loop-name (get-in e [:loop :loop-name])
                    :segment-requirement (get-in e [:loop :segment-requirement])
                  :segment-description (get-in e [:loop :segment-description])
                  :kp-element (:kp-element e)
                  :options (:options e)
                  :element-description (:element-description e)}
                 pred))))
       (filter :segment-id)
       vec))

(defn parse-companion-csv->rules
  [csv-file]
  (println "[parse-companion-csv->rules]")
  (let [text (io/read-text csv-file)
        model (parse-companion-csv->model text)]
    {:model model
     :rules (compile-rules model)}))

(defn- to-ref [segment-id position]
  (str segment-id (zero-pad2 position)))

(defn- extract-seg-id [data-segment-node]
  (some (fn [child]
          (when (tag= child "seg_id")
            (second child)))
        (rest data-segment-node)))

(defn- extract-unit-values [data-segment-node]
  (->> (rest data-segment-node)
       (filter #(tag= % "data_segment_unit"))
       (map (fn [unit]
              (let [second-val (second unit)]
                (if (map? second-val)
                  (nth unit 2 nil)
                  second-val))))
       vec))

(defn- annotate-unit [unit annotation]
  (let [second-val (second unit)]
    (if (map? second-val)
      (let [val (nth unit 2 nil)]
        [(first unit) (merge second-val annotation) val])
      [(first unit) annotation second-val])))

(defn- split-raw-segment
  "Split raw segment text into [segment-id values]."
  [raw]
  (let [parts (str/split (or raw "") #"\*" -1)
        seg-id (first parts)
        values (vec (rest parts))]
    [seg-id values]))

(defn- safe-read-edn
  [text]
  (try
    (reader/read-string text)
    (catch :default _ nil)))

(defn- safe-read-json
  [text]
  (try
    (js->clj (js/JSON.parse text) :keywordize-keys true)
    (catch :default _ nil)))

(defn- env-get
  [k]
  (aget (.-env js/process) k))

(defn- normalize-ssn
  "Canonicalize SSN to digits-only for binds and in-memory state."
  [s]
  (-> (or s "")
      str
      str/trim
      (str/replace #"\D" "")))

(defn- resolve-env-name
  [opts]
  (or (:env-name opts)
      (:envName opts)
      (env-get "envName")
      (env-get "ENV_NAME")))

(defn- db-env-keys
  [env-name]
  {:user-key (str "host." env-name "-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.user")
   :password-key (str "host." env-name "-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.password")
   :url-key (str "host." env-name "-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.url")})

(defn- resolve-db-config
  [opts]
  (let [env-name (resolve-env-name opts)]
    (when-not (blankish? env-name)
      (let [{:keys [user-key password-key url-key]} (db-env-keys env-name)
            user (env-get user-key)
            password (env-get password-key)
            connect-string (env-get url-key)]
        {:env-name env-name
         :user-key user-key
         :password-key password-key
         :url-key url-key
         :user user
         :password password
         :connect-string connect-string
         :valid? (and (not (blankish? user))
                      (not (blankish? password))
                      (not (blankish? connect-string)))}))))

(defn- resolve-subscriber-only-db-validation?
  "Default to subscriber-only DB validation unless explicitly disabled.
   Accepts opts flag or env var SUBSCRIBER_ONLY_DB_VALIDATION=false."
  [opts]
  (let [raw (or (:subscriber-only-db-validation? opts)
                (:subscriberOnlyDbValidation opts)
                (env-get "SUBSCRIBER_ONLY_DB_VALIDATION")
                true)
        v (if (string? raw) (-> raw str str/trim str/lower-case) raw)]
    (cond
      (boolean? v) v
      (string? v) (not (contains? #{"false" "0" "no" "n"} v))
      :else true)))

(defn- loop-name->scope
  [loop-name]
  (let [v (str/trim (or loop-name ""))]
    (cond
      (or (blankish? v)
          (= v "Header")
          (str/starts-with? v "1000")) :commercial
      (re-matches #"^[2-9].*" v) :subscriber
      :else :commercial)))

(defn- ensure-current-subscriber
  [db-state*]
  (let [cur (:current-subscriber @db-state*)]
    (when (nil? cur)
      (swap! db-state* assoc :current-subscriber {:index 1 :ssn nil :refs {}}))))

(defn- start-new-subscriber!
  [db-state*]
  (let [{:keys [current-subscriber subscribers]} @db-state*
        persisted (if (and current-subscriber
                           (or (not (blankish? (:ssn current-subscriber)))
                               (seq (:refs current-subscriber))))
                    (conj subscribers current-subscriber)
                    subscribers)
        next-index (inc (count persisted))]
    (swap! db-state* assoc
           :subscribers persisted
           :current-subscriber {:index next-index :ssn nil :refs {}})))

(defn- maybe-capture-subscriber-ssn!
  [db-state* context seg-id position value]
  (ensure-current-subscriber db-state*)
  (let [v (str/trim (or value ""))
     ssn (normalize-ssn v)]
    (cond
      (and (= seg-id "REF")
           (= position 2)
           (= (str/trim (or (get context "REF01") "")) "0F")
     (re-matches #"\d{9}" ssn))
   (swap! db-state* assoc-in [:current-subscriber :ssn] ssn)

      (and (= seg-id "NM1")
           (= position 9)
           (= (str/trim (or (get context "NM108") "")) "34")
     (re-matches #"\d{9}" ssn)
           (blankish? (get-in @db-state* [:current-subscriber :ssn])))
   (swap! db-state* assoc-in [:current-subscriber :ssn] ssn)

      :else nil)))

(defn- update-db-state!
  [db-state* context rule seg-id position value]
  (let [ref (to-ref seg-id position)
        scope (loop-name->scope (:loop-name rule))
        v (str/trim (or value ""))]
    (when (and (= seg-id "INS") (= position 1))
      (start-new-subscriber! db-state*))
    (when (= scope :subscriber)
      (ensure-current-subscriber db-state*))
    (when (not (blankish? v))
      (if (= scope :commercial)
        (swap! db-state* assoc-in [:commercial-refs ref] value)
        (swap! db-state* assoc-in [:current-subscriber :refs ref] value)))
    ;; Capture SSN from EDI wherever it appears; loop disambiguation can be imperfect.
    (maybe-capture-subscriber-ssn! db-state* context seg-id position value)))

(defn- current-db-context
  [db-state* rule]
  (let [scope (loop-name->scope (:loop-name rule))
        state @db-state*]
    (if (= scope :commercial)
      {:scope :commercial
       :subscriber-index nil
       :subscriber-ssn nil
       :refs (:commercial-refs state)}
      (let [cur (:current-subscriber state)]
        {:scope :subscriber
         :subscriber-index (:index cur)
         :subscriber-ssn (:ssn cur)
         :refs (:refs cur)}))))

(defn- execute-oracle-query-sync
  [db-config sql binds]
  (let [child-proc (js/require "child_process")
        script (str
                "const oracledb=require('oracledb');"
                "(async()=>{"
                "const p=JSON.parse(process.argv[1]);"
                "let conn=null;"
                "try{"
                "conn=await oracledb.getConnection({user:p.user,password:p.password,connectString:p.connectString});"
                "const r=await conn.execute(p.sql,p.binds,{outFormat:oracledb.OUT_FORMAT_OBJECT});"
                "const rows=r.rows||[];"
                "const row=rows[0]||null;"
                "const hit=(row&&(row.HIT_COUNT??row.hit_count))!=null?Number(row.HIT_COUNT??row.hit_count):rows.length;"
                "console.log(JSON.stringify({ok:true,hitCount:hit,rowCount:rows.length,row:row}));"
                "}catch(e){"
                "console.log(JSON.stringify({ok:false,error:e&&e.message?e.message:String(e),code:e&&e.code?e.code:null,errorNum:e&&e.errorNum?e.errorNum:null}));"
                "}finally{if(conn){try{await conn.close();}catch(_){}}}"
                "})();")
        payload (js/JSON.stringify (clj->js {:user (:user db-config)
                                             :password (:password db-config)
                                             :connectString (:connect-string db-config)
                                             :sql sql
                                             :binds binds}))]
    (try
      (let [out (.execFileSync child-proc "node" (clj->js ["-e" script payload]) (clj->js {:encoding "utf8"}))]
        (or (safe-read-json out) {:ok false :error :invalid-db-response}))
      (catch :default e
        (let [stdout (some-> e .-stdout str)
              stderr (some-> e .-stderr str)
              parsed-out (safe-read-json stdout)
              parsed-err (safe-read-json stderr)]
          (or (when (map? parsed-out) parsed-out)
              (when (map? parsed-err) parsed-err)
              {:ok false
               :error (or (when-not (blankish? stdout) stdout)
                          (when-not (blankish? stderr) stderr)
                          (.-message e)
                          :db-exec-failed)}))))))

      (defn- subscriber-sql-by-table
        "Build SSN-anchored subscriber validation SQL for a mapped table/column.
         Returns nil when table strategy is not yet defined."
        [table column]
        (let [person-child #{"TAP_PERSON_ADDRESS" "TAP_PERSON_PHONE" "TAP_PERSON_EMAIL"
                 "TAP_PERSON_LANGUAGE" "TAP_PERSON_EXTERNAL_IDENTIFIER"}
           person-coverage-child #{"TAP_PERSON_COVERAGE_ATTRIBUTE" "TAP_PERSON_COVERAGE_ADDRESS"
                    "TAP_PERSON_COVERAGE_AFFILIATION"
                    "TAP_PERSON_COVERAGE_AFFILIATION_COMM"
                    "TAP_PERSON_COVERAGE_PREMIUM_RATE"
                    "TAP_PERSON_COVERAGE_RIDER"}
           ssn-expr "replace(replace(c.SUBSCRIBER_SSN, '-', ''), ' ', '')"]
          (cond
         (= table "TAP_COVERAGE")
         (str "select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_COVERAGE c "
           "where " ssn-expr " = :ssn and "
           (if (= column "SUBSCRIBER_SSN")
             "replace(replace(c.SUBSCRIBER_SSN, '-', ''), ' ', '')"
             (str "c." column))
           " = :value")

         (= table "TAP_PERSON")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "
           "join MEMBER_OWNER.TAP_PERSON p on p.PERSON_ID = pc.PERSON_ID "
           "where " ssn-expr " = :ssn and p." column " = :value")

         (= table "TAP_PERSON_COVERAGE")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "
           "where " ssn-expr " = :ssn and pc." column " = :value")

         (contains? person-child table)
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "
           "join MEMBER_OWNER." table " t on t.PERSON_ID = pc.PERSON_ID "
           "where " ssn-expr " = :ssn and t." column " = :value")

         (contains? person-coverage-child table)
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "
           "join MEMBER_OWNER." table " t on t.PERSON_ID = pc.PERSON_ID and t.COVERAGE_ID = pc.COVERAGE_ID "
           "where " ssn-expr " = :ssn and t." column " = :value")

         (= table "TAP_PLAN_GROUP")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_PLAN_GROUP pg on pg.PLAN_GROUP_ID = c.PLAN_GROUP_ID "
           "where " ssn-expr " = :ssn and pg." column " = :value")

         (= table "TAP_STAGING_COMPANION")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_STAGING_COMPANION sc "
           "where sc." column " = :value and exists ("
           "select 1 from MEMBER_OWNER.TAP_COVERAGE c "
           "where " ssn-expr " = :ssn and ("
           "c.COVERAGE_ID = sc.SPECIFIED_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.ELIG_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.ELIG_SOURCE_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.PRIMARY_COVERAGE_ID" 
           "))")

         (= table "TAP_BENEFIT_PLAN")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_STAGING_COMPANION sc "
           "join MEMBER_OWNER.TAP_BENEFIT_PLAN bp on bp.BENEFIT_PLAN_ID = sc.BENEFIT_PLAN_ID "
           "where bp." column " = :value and exists ("
           "select 1 from MEMBER_OWNER.TAP_COVERAGE c "
           "where " ssn-expr " = :ssn and ("
           "c.COVERAGE_ID = sc.SPECIFIED_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.ELIG_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.ELIG_SOURCE_COVERAGE_ID or "
           "c.COVERAGE_ID = sc.PRIMARY_COVERAGE_ID" 
           "))")

         (= table "TAP_COVERAGE_THIRD_PARTY_PAYER")
         (str "select count(*) as HIT_COUNT "
           "from MEMBER_OWNER.TAP_COVERAGE c "
           "join MEMBER_OWNER.TAP_COVERAGE_THIRD_PARTY_PAYER tpp on tpp.COVERAGE_ID = c.COVERAGE_ID "
           "where " ssn-expr " = :ssn and tpp." column " = :value")

         :else
         nil)))

(defn- make-oracle-lookup-executor
  [opts]
  (let [db-config (resolve-db-config opts)
        subscriber-only? (resolve-subscriber-only-db-validation? opts)]
    (fn [{:keys [spec value db-context]}]
      (let [scope (:scope db-context)
        ssn (:subscriber-ssn db-context)
        normalized-ssn (normalize-ssn ssn)
            table (:table spec)
            column (:column spec)
            segment-ref (:segment-ref spec)
            text-value (str (or value ""))
        normalized-value (if (= column "SUBSCRIBER_SSN")
               (normalize-ssn text-value)
               value)
            subscriber-sql (subscriber-sql-by-table table column)
            commercial-query
            (if (and (= table "TAP_STAGING_COMPANION")
                     (= column "APPLICATION_TIMESTAMP"))
              (cond
                ;; BGN03 carries CCYYMMDD.
                (and (= segment-ref "BGN03") (boolean (re-matches #"\d{8}" text-value)))
                {:sql "select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'YYYYMMDD') = :value"
                 :binds (clj->js {:value text-value})}

                ;; BGN04 carries HHMMSSDD; compare only HHMMSS to DB timestamp time component.
                (and (= segment-ref "BGN04") (boolean (re-matches #"\d{6,8}" text-value)))
                {:sql "select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'HH24MISS') = :value"
                 :binds (clj->js {:value (subs text-value 0 6)})}

                :else
                {:sql "select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'YYYYMMDDHH24MISS') = :value"
                 :binds (clj->js {:value text-value})})
              (if (and (= table "TAP_COVERAGE") (= column "SUBSCRIBER_SSN"))
                {:sql "select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_COVERAGE where replace(replace(SUBSCRIBER_SSN, '-', ''), ' ', '') = :value"
                 :binds (clj->js {:value (normalize-ssn text-value)})}
              {:sql (str "select count(*) as HIT_COUNT from MEMBER_OWNER." table
                         " where " column " = :value")
               :binds (clj->js {:value value})}))
            sql (if (= scope :subscriber)
                  subscriber-sql
                  (:sql commercial-query))]
        (cond
          (nil? db-config)
          {:executed? false
           :valid false
           :status :db-config-missing
           :reason :missing-env-name}

          (not (:valid? db-config))
          {:executed? false
           :valid false
           :status :db-config-invalid
           :reason {:env-name (:env-name db-config)
                    :user-key (:user-key db-config)
                    :password-key (:password-key db-config)
                    :url-key (:url-key db-config)}}

          (and subscriber-only? (not= scope :subscriber))
          {:executed? false
           :valid true
           :status :skipped-non-subscriber-scope
           :reason :subscriber-only-db-validation}

          (and (= scope :subscriber)
            (not (re-matches #"\d{9}" normalized-ssn)))
          {:executed? false
           :valid true
           :status :missing-subscriber-ssn
           :reason :subscriber-lookups-require-ssn}

          (and (= scope :subscriber) (nil? sql))
          {:executed? false
           :valid true
           :status :skipped-unmapped-subscriber-attribute
           :reason {:table table :column column}}

          :else
            (let [binds (if (= scope :subscriber)
              (clj->js {:value normalized-value :ssn normalized-ssn})
              (:binds commercial-query))
                q (execute-oracle-query-sync db-config sql binds)
                hit (or (:hitCount q) 0)
                ok? (and (:ok q) (> hit 0))]
            {:executed? true
             :valid (boolean ok?)
             :status (if (:ok q)
                       (if ok? :db-hit :db-miss)
                       :db-error)
             :hit-count hit
             :scope scope
             :subscriber-ssn (when (= scope :subscriber) normalized-ssn)
             :reason (when-not (:ok q) (:error q))
             :sql sql}))))))

(defn load-lookup-specs
  "Load generated lookup specs EDN. Returns nil when file cannot be read/parsed."
  [lookup-spec-file]
  (try
    (some-> lookup-spec-file io/read-text safe-read-edn)
    (catch :default _
      nil)))

(defn- build-lookup-index
  "Build a lookup index keyed by [loop segment-id segment-ref]."
  [lookup-doc]
  (let [specs (:specs lookup-doc)]
    (reduce (fn [acc spec]
              (let [k [(:loop spec) (:segment-id spec) (:segment-ref spec)]]
                (assoc acc k spec)))
            {}
            specs)))

(defn- find-lookup-spec
  "Resolve best lookup spec for a rule. Prefer exact loop match, fallback to segment+ref match."
  [lookup-index rule]
  (let [exact-k [(:loop-name rule) (:segment-id rule) (:segment-ref rule)]
        exact (get lookup-index exact-k)]
    (if exact
      exact
      (some (fn [[[_loop seg ref] spec]]
              (when (and (= seg (:segment-id rule))
                         (= ref (:segment-ref rule)))
                spec))
            lookup-index))))

(defn- default-lookup-executor
  "Default executor when no DB integration is provided yet."
  [_]
  {:executed? false
   :valid true
   :status :not-executed
   :reason :no-db-executor-configured})

(defn- evaluate-lookup
  [{:keys [lookup-index lookup-executor include-lookup-sql?]} rule value db-context]
  (cond
    (blankish? value)
    {:lookup-applied false
     :valid true
     :status :skipped-blank}

    (nil? lookup-index)
    {:lookup-applied false
     :valid true
     :status :no-lookup-index}

    :else
    (let [spec (find-lookup-spec lookup-index rule)]
      (cond
        (nil? spec)
        {:lookup-applied false
         :valid true
         :status :no-spec}

        (not (true? (:enabled? spec)))
        {:lookup-applied true
         :valid true
         :status :spec-disabled
         :lookup-spec-id (:id spec)
         :lookup-kind (:lookup-kind spec)
         :reason (:disabled-reason spec)}

        :else
        (let [exec-fn (or lookup-executor default-lookup-executor)
            exec-result (or (exec-fn {:spec spec :rule rule :value value :db-context db-context}) {})
              executed? (boolean (:executed? exec-result))
              lookup-valid? (if (contains? exec-result :valid)
                              (boolean (:valid exec-result))
                              true)]
          (cond-> {:lookup-applied true
                   :valid lookup-valid?
                   :status (or (:status exec-result) (if executed? :executed :not-executed))
                   :executed? executed?
                   :lookup-spec-id (:id spec)
                   :lookup-kind (:lookup-kind spec)
                       :scope (:scope db-context)
                       :subscriber-index (:subscriber-index db-context)
                   :reason (:reason exec-result)}
            include-lookup-sql?
            (assoc :sql (get-in spec [:sql :exists]))))))))

(defn- run-rule-on-value
  "Run one compiled rule against a single element value and update stats/context."
  [context* stats* db-state* rule seg-id position value lookup-state]
  (let [ref (to-ref seg-id position)
        _ (when-not (blankish? value)
            (swap! context* assoc ref value))
        _ (update-db-state! db-state* @context* rule seg-id position value)
        db-context (current-db-context db-state* rule)
        result ((:validate rule) {:value value
                                  :segment-id seg-id
                                  :position position
                                  :context @context*})
        lookup-result (evaluate-lookup lookup-state rule value db-context)
        rule-valid? (boolean (:valid result))
        valid? (and rule-valid? (boolean (:valid lookup-result)))
        annotation {:rule-id (:rule-id rule)
                    :segment-ref (:segment-ref rule)
                    :valid valid?
                    :rule-kind (:kind rule)
                    :lookup lookup-result}]
    (swap! stats* update :total inc)
    (swap! stats* update (if valid? :passed :failed) inc)
    (when (:lookup-applied lookup-result)
      (swap! stats* update-in [:lookup :attempted] (fnil inc 0))
      (swap! stats* update-in [:lookup (if (:valid lookup-result) :passed :failed)] (fnil inc 0)))
    (when (not (:lookup-applied lookup-result))
      (swap! stats* update-in [:lookup :skipped] (fnil inc 0)))
    (swap! stats* update-in [:by-rule (:rule-id rule) :total] (fnil inc 0))
    (swap! stats* update-in [:by-rule (:rule-id rule) (if valid? :passed :failed)] (fnil inc 0))
    (if valid?
      annotation
      (assoc annotation
             :invalid-description
             (pr-str {:rule result
                      :lookup lookup-result})))))

(defn- run-rule-preview
  "Run one rule without mutating global stats/context; returns [annotation next-context]."
  [context rule seg-id position value]
  (let [ref (to-ref seg-id position)
        next-context (if (blankish? value)
                       context
                       (assoc context ref value))
        result ((:validate rule) {:value value
                                  :segment-id seg-id
                                  :position position
                                  :context next-context})
        valid? (boolean (:valid result))
        annotation (cond-> {:rule-id (:rule-id rule)
                            :segment-ref (:segment-ref rule)
                            :valid valid?
                            :rule-kind (:kind rule)}
                     (not valid?)
                     (assoc :invalid-description (pr-str result)))]
    [annotation next-context]))

(defn- choose-loop-aware-rules
  "Pick the best matching loop-specific rules for a segment based on value fit.
   Falls back to all rules when no loop grouping is available."
  [seg-id values seg-rules context expected-loop-name]
  (let [rule-weight (fn [rule]
                      (case (:kind rule)
                        :cross-ref 4
                        :enum 3
                        :external-code-list 2
                        :pattern-hint 2
                        :literal 2
                        :placeholder 1
                        :open 0
                        1))
        groups (->> seg-rules
              (group-by (fn [r] [(:loop-name r) (:segment-description r)]))
              (sort-by key)
              (map (fn [[_ rs]] (sort-by :position rs)))
                    vec)]
    (if (<= (count groups) 1)
      (first groups)
      (let [scored
            (map (fn [rules]
                   (let [result
                         (reduce (fn [{:keys [ctx anns passed failed pass-weight fail-weight]} rule]
                                   (let [position (:position rule)
                                         value (nth values (dec position) nil)
                                         [ann next-ctx] (run-rule-preview ctx rule seg-id position value)
                                         w (rule-weight rule)]
                                     {:ctx next-ctx
                                      :anns (conj anns ann)
                                      :passed (if (:valid ann) (inc passed) passed)
                                      :failed (if (:valid ann) failed (inc failed))
                                      :pass-weight (if (:valid ann) (+ pass-weight w) pass-weight)
                                      :fail-weight (if (:valid ann) fail-weight (+ fail-weight w))}))
                                 {:ctx context :anns [] :passed 0 :failed 0 :pass-weight 0 :fail-weight 0}
                                 rules)]
                     {:rules rules
                      :passed (:passed result)
                      :failed (:failed result)
                      :score [(:pass-weight result)
                              (- (:fail-weight result))
                              (if (and expected-loop-name
                                       (= expected-loop-name (:loop-name (first rules))))
                                1
                                0)
                              (if (= :required (:segment-requirement (first rules))) 1 0)
                              (:passed result)
                              (- (:failed result))
                              (count rules)]}))
                 groups)
            scoped-scored (if expected-loop-name
                            (let [m (filter (fn [{:keys [rules]}]
                                              (= expected-loop-name (:loop-name (first rules))))
                                            scored)]
                              (if (seq m) m scored))
                            scored)]
        (:rules (apply max-key :score scoped-scored))))))

(defn- build-loop-order-by-segment
  "Build per-segment loop order and whether occurrence-based advancement is safe.
   Advancement is disabled when a segment has multiple variants within a loop
   (e.g., REF variants in loop 2000)."
  [rules]
  (let [with-loop (filter (fn [{:keys [segment-id loop-name]}]
                            (and (not (blankish? segment-id))
                                 (not (blankish? loop-name))))
                          rules)
        order-map
        (reduce
         (fn [acc {:keys [segment-id loop-name]}]
           (let [existing (get acc segment-id [])]
             (if (some #(= % loop-name) existing)
               acc
               (assoc acc segment-id (conj existing loop-name)))))
         {}
         with-loop)
        multi-variant?
        (->> with-loop
             (group-by (fn [{:keys [segment-id loop-name]}] [segment-id loop-name]))
             (reduce (fn [acc [[segment-id _] rs]]
                       (let [variant-count (->> rs (map :segment-description) distinct count)]
                         (if (> variant-count 1)
                           (assoc acc segment-id true)
                           acc)))
                     {}))]
    (into {}
          (map (fn [[segment-id order]]
                 [segment-id {:order order
                              :advance-by-occurrence? (not (true? (get multi-variant? segment-id false)))}])
               order-map))))

(defn- expected-loop-for-occurrence
  "Given zero-based segment occurrence, return preferred loop name by companion order."
  [loop-order-by-seg seg-id occurrence]
  (let [{:keys [order advance-by-occurrence?]} (get loop-order-by-seg seg-id)]
    (when (seq order)
      (if advance-by-occurrence?
        (nth order (min occurrence (dec (count order))) nil)
        (first order)))))

(defn validate-edi-parse-tree
  "Validate parsed EDI tree using compiled rules and annotate data units with :valid.
   Works with keyword-tag or string-tag parse trees."
  ([parse-tree rules]
   (validate-edi-parse-tree parse-tree rules {}))
  ([parse-tree rules opts]
   (let [rules-by-seg (group-by :segment-id rules)
      loop-order-by-seg (build-loop-order-by-segment rules)
      seg-occurrence* (atom {})
        context* (atom {})
        db-state* (atom {:commercial-refs {}
                         :subscribers []
                         :current-subscriber nil})
        stats* (atom {:total 0 :passed 0 :failed 0 :by-rule {} :lookup {:attempted 0 :passed 0 :failed 0 :skipped 0}})
        lookup-state {:lookup-index (:lookup-index opts)
                      :lookup-executor (:lookup-executor opts)
                      :include-lookup-sql? (true? (:include-lookup-sql? opts))}
        enrich
        (fn enrich [node]
          (if-not (sequential? node)
            node
            (cond
              (tag= node "data_segment")
              (let [seg-id (extract-seg-id node)
                    values (extract-unit-values node)
                    occurrence (get @seg-occurrence* seg-id 0)
                    _ (swap! seg-occurrence* update seg-id (fnil inc 0))
                    expected-loop (expected-loop-for-occurrence loop-order-by-seg seg-id occurrence)
                    seg-rules (sort-by :position (get rules-by-seg seg-id []))
                    active-rules (choose-loop-aware-rules seg-id values seg-rules @context* expected-loop)
                    children (vec (rest node))
                    unit-idxs (->> children
                                   (map-indexed vector)
                                   (filter (fn [[_ c]] (tag= c "data_segment_unit")))
                                   (map first)
                                   vec)
                    pos->rule (into {} (map (juxt :position identity) active-rules))
                    new-children
                    (reduce
                     (fn [acc [pos unit-index]]
                       (let [position (inc pos)
                             unit (nth acc unit-index)
                             value (nth values pos nil)
                             ref (to-ref seg-id position)
                             _ (when-not (blankish? value)
                                 (swap! context* assoc ref value))
                             rule (get pos->rule position)]
                         (if (nil? rule)
                           acc
                           (let [annotation (run-rule-on-value context* stats* db-state* rule seg-id position value lookup-state)]
                             (assoc acc unit-index (annotate-unit unit annotation))))))
                     children
                     (map-indexed vector unit-idxs))]
                (into [(first node)] (map enrich new-children)))

              (tag= node "raw_segment")
              (let [raw-text (second node)
                    [seg-id values] (split-raw-segment raw-text)
                    occurrence (get @seg-occurrence* seg-id 0)
                    _ (swap! seg-occurrence* update seg-id (fnil inc 0))
                    expected-loop (expected-loop-for-occurrence loop-order-by-seg seg-id occurrence)
                    seg-rules (sort-by :position (get rules-by-seg seg-id []))
                    active-rules (choose-loop-aware-rules seg-id values seg-rules @context* expected-loop)
                    annotations
                    (->> active-rules
                         (map (fn [rule]
                                (let [position (:position rule)
                                      value (nth values (dec position) nil)]
                              (run-rule-on-value context* stats* db-state* rule seg-id position value lookup-state))))
                         vec)
                    segment-valid? (every? :valid annotations)]
                (if (seq annotations)
                  [(first node)
                   {:segment-id seg-id
                    :expected-loop expected-loop
                    :loop-name (:loop-name (first active-rules))
                    :loop-description (:segment-description (first active-rules))
                    :segment-requirement (:segment-requirement (first active-rules))
                    :validated-count (count annotations)
                    :valid segment-valid?
                    :element-validations annotations}
                   raw-text]
                  node))

              :else
              (into [(first node)] (map enrich (rest node))))))]
                 {:annotated-tree (enrich parse-tree)
                  :stats @stats*
                  :context @context*
                  :db-state @db-state*})))

(defn validate-parsed-json-text
  "Validate parsed EDI JSON text (array-based parse tree with string tags).
   Returns cljs map including annotated tree and summary stats."
  [parsed-json-text rules]
  (let [parsed (js/JSON.parse parsed-json-text)
        parse-tree (js->clj parsed)]
    (validate-edi-parse-tree parse-tree rules)))

(defn run-rule-harness
  "Test harness: parse companion CSV -> compile rules -> parse an EDI file -> validate.
  Returns parsed tree, annotated tree, and summary focused on validation coverage."
  ([companion-csv edi-file]
   (run-rule-harness companion-csv edi-file {}))
  ([companion-csv edi-file opts]
   (println "[run-rule-harness]")
   (let [{:keys [rules model]} (parse-companion-csv->rules companion-csv)
      lookup-spec-file (or (:lookup-spec-file opts) "save/companion-db-lookups.edn")
       lookup-doc (load-lookup-specs lookup-spec-file)
       lookup-index (build-lookup-index lookup-doc)
       db-enabled? (or (true? (:db-validation? opts))
                       (= "true" (str/lower-case (str (or (env-get "DB_VALIDATION") ""))))
                       (= "1" (str (or (env-get "DB_VALIDATION") ""))))
       effective-lookup-executor (or (:lookup-executor opts)
                                     (when db-enabled?
                                       (make-oracle-lookup-executor opts)))
       db-config (when db-enabled? (resolve-db-config opts))
         parse-tree (parser/parse-x12-full edi-file (select-keys opts [:log-memory?]))
       {:keys [annotated-tree stats context db-state]} (validate-edi-parse-tree parse-tree rules
                          {:lookup-index lookup-index
                           :lookup-executor effective-lookup-executor
                           :include-lookup-sql? (:include-lookup-sql? opts)})
         report {:legend-count (count (:legend model))
                 :loop-count (count (:loops model))
                 :element-row-count (count (:elements model))
                 :rule-count (count rules)
                 :rule-kind-counts (frequencies (map :kind rules))
                 :validation stats
           :context-keys (count context)
           :lookup-spec-file lookup-spec-file
           :lookup-spec-count (count (:specs lookup-doc))
           :lookup-summary (:lookup stats)
           :db-validation-enabled db-enabled?
           :db-env-name (:env-name db-config)
           :subscriber-count (count (concat (:subscribers db-state)
                                            (when-let [cur (:current-subscriber db-state)]
                                              [cur])))}]
     {:report report
      :rules rules
      :parsed-tree parse-tree
      :annotated-tree annotated-tree})))

(defn run-rule-harness-on-test1
  "Convenience harness for local baseline checks using test1.txt."
  []
  (run-rule-harness
   "src/main/resources/TrentonSystemsInc_GA_CompanionDoc_5010a1-2025-12-29.csv"
   "src/main/resources/edisamples/test1.txt"))

(defn- ensure-parent-dir!
  [output-file]
  (let [path-mod (js/require "path")
        fs (js/require "fs")
        dir (.dirname path-mod output-file)]
    (.mkdirSync fs dir (clj->js {:recursive true}))))

(defn write-rule-harness-edn!
  "Run harness and write pretty EDN output to file.
   Returns {:output-file ... :result ...}."
  ([companion-csv edi-file output-file]
   (println "[write-rule-harness-edn!]")
   (let [result (run-rule-harness companion-csv edi-file)
         edn-text (io/to-edn-text result)]
     (ensure-parent-dir! output-file)
     (io/write-text output-file edn-text)
     {:output-file output-file
      :result result}))
  ([companion-csv edi-file output-file opts]
   (let [result (run-rule-harness companion-csv edi-file opts)
         edn-text (io/to-edn-text result)]
     (ensure-parent-dir! output-file)
     (io/write-text output-file edn-text)
     {:output-file output-file
      :result result})))

(defn write-rule-harness-json!
  "Run harness and write pretty JSON output to file.
   Returns {:output-file ... :result ...}."
  ([companion-csv edi-file output-file]
   (let [result (run-rule-harness companion-csv edi-file)
         json-text (.stringify js/JSON (clj->js result) nil 2)]
     (ensure-parent-dir! output-file)
     (io/write-text output-file json-text)
     {:output-file output-file
      :result result}))
  ([companion-csv edi-file output-file opts]
   (let [result (run-rule-harness companion-csv edi-file opts)
         json-text (.stringify js/JSON (clj->js result) nil 2)]
     (ensure-parent-dir! output-file)
     (io/write-text output-file json-text)
     {:output-file output-file
      :result result})))

(defn- default-json-output-file
  [edn-output-file]
  (if (str/ends-with? (or edn-output-file "") ".edn")
    (str (subs edn-output-file 0 (- (count edn-output-file) 4)) ".json")
    (str edn-output-file ".json")))

(defn write-rule-harness-on-test1-edn!
  "Run run-rule-harness-on-test1 and write pretty EDN output for detailed review.
  Also writes JSON output alongside EDN.
  Default outputs: save/rule-harness-test1.edn and save/rule-harness-test1.json"
  ([]
   (println "just checking.....")
  (write-rule-harness-on-test1-edn! "save/rule-harness-test1.edn"))
  ([output-file]
   (let [companion-csv "src/main/resources/TrentonSystemsInc_GA_CompanionDoc_5010a1-2025-12-29.csv"
         edi-file "src/main/resources/edisamples/test1.txt"
         json-output-file (default-json-output-file output-file)
         edn-resp (write-rule-harness-edn! companion-csv edi-file output-file)
         json-resp (write-rule-harness-json! companion-csv edi-file json-output-file)]
     {:edn-output-file (:output-file edn-resp)
      :json-output-file (:output-file json-resp)
      :result (:result edn-resp)})))
