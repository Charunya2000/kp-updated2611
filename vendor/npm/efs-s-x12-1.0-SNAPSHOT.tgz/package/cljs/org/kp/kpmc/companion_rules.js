// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('org.kp.kpmc.companion_rules');
goog.require('cljs.core');
goog.require('cljs.reader');
goog.require('clojure.string');
goog.require('org.kp.kpmc.companion');
goog.require('org.kp.kpmc.io_node');
goog.require('org.kp.kpmc.parser');
org.kp.kpmc.companion_rules.blankish_QMARK_ = (function org$kp$kpmc$companion_rules$blankish_QMARK_(s){
return (((s == null)) || (clojure.string.blank_QMARK_.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(s)))));
});
org.kp.kpmc.companion_rules.tag_name = (function org$kp$kpmc$companion_rules$tag_name(x){
if((x instanceof cljs.core.Keyword)){
return cljs.core.name.call(null,x);
} else {
if(typeof x === 'string'){
return x;
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(x));

}
}
});
org.kp.kpmc.companion_rules.tag_EQ_ = (function org$kp$kpmc$companion_rules$tag_EQ_(node,t){
return ((cljs.core.sequential_QMARK_.call(null,node)) && (cljs.core._EQ_.call(null,org.kp.kpmc.companion_rules.tag_name.call(null,cljs.core.first.call(null,node)),t)));
});
org.kp.kpmc.companion_rules.normalize_usage = (function org$kp$kpmc$companion_rules$normalize_usage(raw){
var v = clojure.string.trim.call(null,(function (){var or__5142__auto__ = raw;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
var G__2064 = v;
switch (G__2064) {
case "R":
return new cljs.core.Keyword(null,"required","required",1807647006);

break;
case "S":
return new cljs.core.Keyword(null,"situational","situational",-374859609);

break;
case "Not Used":
return new cljs.core.Keyword(null,"not-used","not-used",-330157808);

break;
default:
return new cljs.core.Keyword(null,"unknown","unknown",-935977881);

}
});
org.kp.kpmc.companion_rules.zero_pad2 = (function org$kp$kpmc$companion_rules$zero_pad2(n){
if((n < (10))){
return (""+"0"+cljs.core.str.cljs$core$IFn$_invoke$arity$1(n));
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(n));
}
});
/**
 * Parse companion guide CSV into a rich model with legend, loops, and rows.
 * Handles continuation option rows where cols A/B are blank.
 */
org.kp.kpmc.companion_rules.parse_companion_csv__GT_model = (function org$kp$kpmc$companion_rules$parse_companion_csv__GT_model(csv_text){
var rows = cljs.core.vec.call(null,cljs.core.map.call(null,(function (p1__2067_SHARP_){
return cljs.core.subvec.call(null,p1__2067_SHARP_,(0),(5));
}),cljs.core.map.call(null,(function (p1__2066_SHARP_){
return cljs.core.vec.call(null,cljs.core.concat.call(null,p1__2066_SHARP_,cljs.core.repeat.call(null,(5),"")));
}),cljs.core.map.call(null,org.kp.kpmc.companion.parse_csv_line,org.kp.kpmc.companion.join_multiline_quoted_fields.call(null,csv_text)))));
var header_idx = cljs.core.first.call(null,cljs.core.keep_indexed.call(null,(function (idx,row){
if(cljs.core._EQ_.call(null,"Ref. Des.",clojure.string.trim.call(null,cljs.core.nth.call(null,row,(1),"")))){
return idx;
} else {
return null;
}
}),rows));
var legend_rows = (cljs.core.truth_(header_idx)?cljs.core.subvec.call(null,rows,(0),header_idx):cljs.core.PersistentVector.EMPTY);
var body_rows = (cljs.core.truth_(header_idx)?cljs.core.subvec.call(null,rows,(header_idx + (1))):cljs.core.PersistentVector.EMPTY);
var legend_start = cljs.core.first.call(null,cljs.core.keep_indexed.call(null,(function (idx,row){
if(cljs.core._EQ_.call(null,"Legend",clojure.string.trim.call(null,cljs.core.nth.call(null,row,(0),"")))){
return idx;
} else {
return null;
}
}),legend_rows));
var legend_pairs = (((legend_start == null))?cljs.core.PersistentVector.EMPTY:cljs.core.vec.call(null,cljs.core.map.call(null,(function (p__2068){
var vec__2069 = p__2068;
var k = cljs.core.nth.call(null,vec__2069,(0),null);
var v = cljs.core.nth.call(null,vec__2069,(1),null);
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"key","key",-1516042587),k,new cljs.core.Keyword(null,"value","value",305978217),v], null);
}),cljs.core.filter.call(null,(function (p__2072){
var vec__2073 = p__2072;
var k = cljs.core.nth.call(null,vec__2073,(0),null);
var v = cljs.core.nth.call(null,vec__2073,(1),null);
return (((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,k)))) || ((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,v)))));
}),cljs.core.map.call(null,(function (row){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [clojure.string.trim.call(null,cljs.core.nth.call(null,row,(0),"")),clojure.string.trim.call(null,cljs.core.nth.call(null,row,(1),""))], null);
}),cljs.core.subvec.call(null,legend_rows,(legend_start + (1))))))));
var remaining = body_rows;
var current_loop = null;
var current_element = null;
var loops = cljs.core.PersistentVector.EMPTY;
var elements = cljs.core.PersistentVector.EMPTY;
while(true){
if(cljs.core.empty_QMARK_.call(null,remaining)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"legend","legend",-1027192245),legend_pairs,new cljs.core.Keyword(null,"loops","loops",-1766681555),loops,new cljs.core.Keyword(null,"elements","elements",657646735),(function (){var G__2081 = elements;
if(cljs.core.truth_(current_element)){
return cljs.core.conj.call(null,G__2081,current_element);
} else {
return G__2081;
}
})()], null);
} else {
var vec__2082 = cljs.core.first.call(null,remaining);
var col_a = cljs.core.nth.call(null,vec__2082,(0),null);
var col_b = cljs.core.nth.call(null,vec__2082,(1),null);
var col_c = cljs.core.nth.call(null,vec__2082,(2),null);
var col_d = cljs.core.nth.call(null,vec__2082,(3),null);
var col_e = cljs.core.nth.call(null,vec__2082,(4),null);
var a = clojure.string.trim.call(null,col_a);
var b = clojure.string.trim.call(null,col_b);
var c = clojure.string.trim.call(null,col_c);
var d = clojure.string.trim.call(null,col_d);
var e = clojure.string.trim.call(null,col_e);
var loop_line_QMARK_ = clojure.string.starts_with_QMARK_.call(null,a,"Loop:");
var ref_row_QMARK_ = (!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,b)));
var cont_option_row_QMARK_ = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,a)) && (((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,b)) && ((((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,d)))) && ((!((current_element == null)))))))));
if(loop_line_QMARK_){
var next_loop = org.kp.kpmc.companion.parse_loop_header.call(null,a);
var G__2086 = cljs.core.rest.call(null,remaining);
var G__2087 = next_loop;
var G__2088 = current_element;
var G__2089 = (cljs.core.truth_(next_loop)?cljs.core.conj.call(null,loops,next_loop):loops);
var G__2090 = elements;
remaining = G__2086;
current_loop = G__2087;
current_element = G__2088;
loops = G__2089;
elements = G__2090;
continue;
} else {
if(ref_row_QMARK_){
var next_element = new cljs.core.PersistentArrayMap(null, 7, [new cljs.core.Keyword(null,"loop","loop",-395552849),current_loop,new cljs.core.Keyword(null,"label","label",1718410804),a,new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482),b,new cljs.core.Keyword(null,"usage","usage",-1583752910),org.kp.kpmc.companion_rules.normalize_usage.call(null,c),new cljs.core.Keyword(null,"kp-element","kp-element",1092855431),d,new cljs.core.Keyword(null,"element-description","element-description",1941111197),e,new cljs.core.Keyword(null,"options","options",99638489),cljs.core.PersistentVector.EMPTY], null);
var G__2091 = cljs.core.rest.call(null,remaining);
var G__2092 = current_loop;
var G__2093 = next_element;
var G__2094 = loops;
var G__2095 = (function (){var G__2085 = elements;
if(cljs.core.truth_(current_element)){
return cljs.core.conj.call(null,G__2085,current_element);
} else {
return G__2085;
}
})();
remaining = G__2091;
current_loop = G__2092;
current_element = G__2093;
loops = G__2094;
elements = G__2095;
continue;
} else {
if(cont_option_row_QMARK_){
var opt = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"usage","usage",-1583752910),org.kp.kpmc.companion_rules.normalize_usage.call(null,c),new cljs.core.Keyword(null,"kp-element","kp-element",1092855431),d,new cljs.core.Keyword(null,"element-description","element-description",1941111197),e], null);
var G__2096 = cljs.core.rest.call(null,remaining);
var G__2097 = current_loop;
var G__2098 = cljs.core.update.call(null,current_element,new cljs.core.Keyword(null,"options","options",99638489),cljs.core.conj,opt);
var G__2099 = loops;
var G__2100 = elements;
remaining = G__2096;
current_loop = G__2097;
current_element = G__2098;
loops = G__2099;
elements = G__2100;
continue;
} else {
var G__2101 = cljs.core.rest.call(null,remaining);
var G__2102 = current_loop;
var G__2103 = current_element;
var G__2104 = loops;
var G__2105 = elements;
remaining = G__2101;
current_loop = G__2102;
current_element = G__2103;
loops = G__2104;
elements = G__2105;
continue;

}
}
}
}
break;
}
});
org.kp.kpmc.companion_rules.parse_length_limit = (function org$kp$kpmc$companion_rules$parse_length_limit(desc){
var temp__5825__auto__ = cljs.core.re_find.call(null,/up to\s+(\d+)\s+bytes/i,(function (){var or__5142__auto__ = desc;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
if(cljs.core.truth_(temp__5825__auto__)){
var m = temp__5825__auto__;
return parseInt(cljs.core.second.call(null,m),(10));
} else {
return null;
}
});
org.kp.kpmc.companion_rules.split_options = (function org$kp$kpmc$companion_rules$split_options(s){
var norm = clojure.string.replace.call(null,clojure.string.replace.call(null,(function (){var or__5142__auto__ = s;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})(),/\s+or\s+/,","),/\bor\b/,",");
return cljs.core.vec.call(null,cljs.core.remove.call(null,org.kp.kpmc.companion_rules.blankish_QMARK_,cljs.core.map.call(null,clojure.string.trim,clojure.string.split.call(null,norm,/,/))));
});
org.kp.kpmc.companion_rules.placeholder_kind = (function org$kp$kpmc$companion_rules$placeholder_kind(kp){
if(cljs.core._EQ_.call(null,kp,"<Blank>")){
return new cljs.core.Keyword(null,"blank","blank",-1249652109);
} else {
if(cljs.core._EQ_.call(null,kp,"<YYMMDD>")){
return new cljs.core.Keyword(null,"yymmdd","yymmdd",-870206005);
} else {
if(cljs.core._EQ_.call(null,kp,"<CCYYMMDD>")){
return new cljs.core.Keyword(null,"ccyymmdd","ccyymmdd",1143135339);
} else {
if(cljs.core._EQ_.call(null,kp,"<HHMM>")){
return new cljs.core.Keyword(null,"hhmm","hhmm",574522753);
} else {
if(cljs.core._EQ_.call(null,kp,"<HHMMSS>")){
return new cljs.core.Keyword(null,"hhmmss","hhmmss",1315391223);
} else {
if(cljs.core._EQ_.call(null,kp,"<HHMMSSDD>")){
return new cljs.core.Keyword(null,"hhmmssdd","hhmmssdd",46476879);
} else {
if(cljs.core._EQ_.call(null,kp,"<Number>")){
return new cljs.core.Keyword(null,"number","number",1570378438);
} else {
if(cljs.core._EQ_.call(null,kp,"<Unique Number>")){
return new cljs.core.Keyword(null,"unique-number","unique-number",-655810364);
} else {
if(cljs.core._EQ_.call(null,kp,"<Area Code><Phone>")){
return new cljs.core.Keyword(null,"phone10","phone10",1993045959);
} else {
if(cljs.core._EQ_.call(null,kp,"<Subscriber SSN>")){
return new cljs.core.Keyword(null,"ssn","ssn",1659668683);
} else {
if(cljs.core._EQ_.call(null,kp,"Subscriber SSN")){
return new cljs.core.Keyword(null,"ssn","ssn",1659668683);
} else {
if(cljs.core._EQ_.call(null,kp,"XXXXXXXXXXXXXXX")){
return new cljs.core.Keyword(null,"x-mask","x-mask",597326196);
} else {
if(cljs.core._EQ_.call(null,kp,"<All Possible Codes>")){
return new cljs.core.Keyword(null,"all-possible-codes","all-possible-codes",-884107306);
} else {
if(cljs.core._EQ_.call(null,kp,"All values")){
return new cljs.core.Keyword(null,"all-values","all-values",727631771);
} else {
return null;

}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
/**
 * Special companion guide case: 'All Values,336(Hire Date)' means value must be 336.
 */
org.kp.kpmc.companion_rules.all_values_336_rule_QMARK_ = (function org$kp$kpmc$companion_rules$all_values_336_rule_QMARK_(kp){
return cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\s*All\s+Values\s*,\s*336(?:\s*\(.*\))?\s*/i,(function (){var or__5142__auto__ = kp;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()));
});
/**
 * For enum rules, required fields must match allowed values; optional fields may be blank.
 */
org.kp.kpmc.companion_rules.enum_valid_QMARK_ = (function org$kp$kpmc$companion_rules$enum_valid_QMARK_(usage,allowed_values,value){
var v = clojure.string.trim.call(null,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
var allowed_QMARK_ = cljs.core.contains_QMARK_.call(null,allowed_values,v);
if(cljs.core._EQ_.call(null,usage,new cljs.core.Keyword(null,"required","required",1807647006))){
return allowed_QMARK_;
} else {
return ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,v)) || (allowed_QMARK_));
}
});
/**
 * Detect the HD01 companion rule that is conditioned by BGN08 values.
 */
org.kp.kpmc.companion_rules.hd01_rule_QMARK_ = (function org$kp$kpmc$companion_rules$hd01_rule_QMARK_(rule){
return ((cljs.core._EQ_.call(null,"HD01",new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(rule))) && (cljs.core._EQ_.call(null,"001, 021, 024, 030",clojure.string.trim.call(null,(function (){var or__5142__auto__ = new cljs.core.Keyword(null,"kp-element","kp-element",1092855431).cljs$core$IFn$_invoke$arity$1(rule);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))));
});
/**
 * Allowed HD01 values based on captured BGN08 action code.
 * BGN08=2 => 001/021/024, BGN08=4 or RX => 030.
 * If BGN08 is unavailable, keep permissive base set.
 */
org.kp.kpmc.companion_rules.hd01_allowed_by_bgn08 = (function org$kp$kpmc$companion_rules$hd01_allowed_by_bgn08(context){
var bgn08 = clojure.string.trim.call(null,(function (){var or__5142__auto__ = cljs.core.get.call(null,context,"BGN08");
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
if(cljs.core._EQ_.call(null,bgn08,"2")){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, ["021",null,"024",null,"001",null], null), null);
} else {
if(((cljs.core._EQ_.call(null,bgn08,"4")) || (cljs.core._EQ_.call(null,bgn08,"RX")))){
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["030",null], null), null);
} else {
return new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 4, ["021",null,"024",null,"030",null,"001",null], null), null);

}
}
});
/**
 * True for angle-bracket tokens that represent external references, e.g. <Fed Tax Id>.
 */
org.kp.kpmc.companion_rules.external_ref_token_QMARK_ = (function org$kp$kpmc$companion_rules$external_ref_token_QMARK_(kp){
return cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/^<[^>]+>$/,(function (){var or__5142__auto__ = kp;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()));
});
/**
 * True when a KP element expression contains any angle-bracket token text.
 */
org.kp.kpmc.companion_rules.contains_angle_token_QMARK_ = (function org$kp$kpmc$companion_rules$contains_angle_token_QMARK_(kp){
return cljs.core.boolean$.call(null,cljs.core.re_find.call(null,/[<>]/,(function (){var or__5142__auto__ = kp;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()));
});
org.kp.kpmc.companion_rules.build_rule_predicate = (function org$kp$kpmc$companion_rules$build_rule_predicate(rule){
var kp = new cljs.core.Keyword(null,"kp-element","kp-element",1092855431).cljs$core$IFn$_invoke$arity$1(rule);
var desc = new cljs.core.Keyword(null,"element-description","element-description",1941111197).cljs$core$IFn$_invoke$arity$1(rule);
var p_kind = org.kp.kpmc.companion_rules.placeholder_kind.call(null,kp);
var ref_match = cljs.core.re_find.call(null,/^<Same as\s+([A-Z0-9]{2,3}[0-9]{2})>$/,kp);
var option_values = cljs.core.vec.call(null,cljs.core.distinct.call(null,cljs.core.remove.call(null,org.kp.kpmc.companion_rules.external_ref_token_QMARK_,cljs.core.remove.call(null,(function (p1__2106_SHARP_){
return cljs.core._EQ_.call(null,p1__2106_SHARP_,"<Blank>");
}),cljs.core.remove.call(null,org.kp.kpmc.companion_rules.blankish_QMARK_,cljs.core.mapcat.call(null,org.kp.kpmc.companion_rules.split_options,cljs.core.map.call(null,clojure.string.trim,cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [kp], null),cljs.core.map.call(null,new cljs.core.Keyword(null,"kp-element","kp-element",1092855431),new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(rule))))))))));
var x_max_len = org.kp.kpmc.companion_rules.parse_length_limit.call(null,desc);
if(cljs.core.truth_(ref_match)){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"cross-ref","cross-ref",-968358296),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2107){
var map__2108 = p__2107;
var map__2108__$1 = cljs.core.__destructure_map.call(null,map__2108);
var value = cljs.core.get.call(null,map__2108__$1,new cljs.core.Keyword(null,"value","value",305978217));
var context = cljs.core.get.call(null,map__2108__$1,new cljs.core.Keyword(null,"context","context",-830191113));
var ref = cljs.core.second.call(null,ref_match);
var expected = cljs.core.get.call(null,context,ref);
if(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,expected)){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"note","note",1426297904),new cljs.core.Keyword(null,"missing-reference-context","missing-reference-context",209526069)], null);
} else {
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core._EQ_.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(value)),(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(expected))),new cljs.core.Keyword(null,"expected","expected",1583670997),expected,new cljs.core.Keyword(null,"actual","actual",107306363),value], null);
}
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"blank","blank",-1249652109))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2109){
var map__2110 = p__2109;
var map__2110__$1 = cljs.core.__destructure_map.call(null,map__2110);
var value = cljs.core.get.call(null,map__2110__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value)], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"yymmdd","yymmdd",-870206005))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2111){
var map__2112 = p__2111;
var map__2112__$1 = cljs.core.__destructure_map.call(null,map__2112);
var value = cljs.core.get.call(null,map__2112__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{6}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"ccyymmdd","ccyymmdd",1143135339))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2113){
var map__2114 = p__2113;
var map__2114__$1 = cljs.core.__destructure_map.call(null,map__2114);
var value = cljs.core.get.call(null,map__2114__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{8}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"hhmm","hhmm",574522753))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2115){
var map__2116 = p__2115;
var map__2116__$1 = cljs.core.__destructure_map.call(null,map__2116);
var value = cljs.core.get.call(null,map__2116__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{4}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"hhmmss","hhmmss",1315391223))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2117){
var map__2118 = p__2117;
var map__2118__$1 = cljs.core.__destructure_map.call(null,map__2118);
var value = cljs.core.get.call(null,map__2118__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{6}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"hhmmssdd","hhmmssdd",46476879))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2119){
var map__2120 = p__2119;
var map__2120__$1 = cljs.core.__destructure_map.call(null,map__2120);
var value = cljs.core.get.call(null,map__2120__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{6,8}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(((cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"number","number",1570378438))) || (cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"unique-number","unique-number",-655810364))))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2121){
var map__2122 = p__2121;
var map__2122__$1 = cljs.core.__destructure_map.call(null,map__2122);
var value = cljs.core.get.call(null,map__2122__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d+/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"phone10","phone10",1993045959))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2123){
var map__2124 = p__2123;
var map__2124__$1 = cljs.core.__destructure_map.call(null,map__2124);
var value = cljs.core.get.call(null,map__2124__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{10}/,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"ssn","ssn",1659668683))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2125){
var map__2126 = p__2125;
var map__2126__$1 = cljs.core.__destructure_map.call(null,map__2126);
var value = cljs.core.get.call(null,map__2126__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value)) || (cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{9}/,(function (){var or__5142__auto____$1 = value;
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
return "";
}
})()))))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"x-mask","x-mask",597326196))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"pattern-hint","pattern-hint",1360513039),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2127){
var map__2128 = p__2127;
var map__2128__$1 = cljs.core.__destructure_map.call(null,map__2128);
var value = cljs.core.get.call(null,map__2128__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),(cljs.core.truth_(x_max_len)?(cljs.core.count.call(null,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()) <= x_max_len):(!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))))], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"all-values","all-values",727631771))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"open","open",-1763596448),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (_){
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),true], null);
})], null);
} else {
if(org.kp.kpmc.companion_rules.all_values_336_rule_QMARK_.call(null,kp)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"enum","enum",1679018432),new cljs.core.Keyword(null,"allowed","allowed",1436019743),new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["336",null], null), null),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2129){
var map__2130 = p__2129;
var map__2130__$1 = cljs.core.__destructure_map.call(null,map__2130);
var value = cljs.core.get.call(null,map__2130__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),org.kp.kpmc.companion_rules.enum_valid_QMARK_.call(null,new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["336",null], null), null),value),new cljs.core.Keyword(null,"allowed","allowed",1436019743),new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, ["336"], null)], null);
})], null);
} else {
if(cljs.core._EQ_.call(null,p_kind,new cljs.core.Keyword(null,"all-possible-codes","all-possible-codes",-884107306))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"external-code-list","external-code-list",-831532177),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2131){
var map__2132 = p__2131;
var map__2132__$1 = cljs.core.__destructure_map.call(null,map__2132);
var value = cljs.core.get.call(null,map__2132__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"required","required",1807647006)))?(!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))):true),new cljs.core.Keyword(null,"note","note",1426297904),new cljs.core.Keyword(null,"external-code-list","external-code-list",-831532177)], null);
})], null);
} else {
if(org.kp.kpmc.companion_rules.hd01_rule_QMARK_.call(null,rule)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"enum","enum",1679018432),new cljs.core.Keyword(null,"allowed","allowed",1436019743),new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 4, ["021",null,"024",null,"030",null,"001",null], null), null),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2133){
var map__2134 = p__2133;
var map__2134__$1 = cljs.core.__destructure_map.call(null,map__2134);
var value = cljs.core.get.call(null,map__2134__$1,new cljs.core.Keyword(null,"value","value",305978217));
var context = cljs.core.get.call(null,map__2134__$1,new cljs.core.Keyword(null,"context","context",-830191113));
var allowed = org.kp.kpmc.companion_rules.hd01_allowed_by_bgn08.call(null,context);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"valid","valid",155614240),org.kp.kpmc.companion_rules.enum_valid_QMARK_.call(null,new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(rule),allowed,value),new cljs.core.Keyword(null,"allowed","allowed",1436019743),cljs.core.vec.call(null,allowed),new cljs.core.Keyword(null,"based-on","based-on",1217703581),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"BGN08","BGN08",778448405),cljs.core.get.call(null,context,"BGN08")], null)], null);
})], null);
} else {
if(((org.kp.kpmc.companion_rules.contains_angle_token_QMARK_.call(null,kp)) && (((clojure.string.includes_QMARK_.call(null,kp,"<Blank>")) && (cljs.core.seq.call(null,option_values)))))){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"enum","enum",1679018432),new cljs.core.Keyword(null,"allowed","allowed",1436019743),cljs.core.set.call(null,option_values),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2135){
var map__2136 = p__2135;
var map__2136__$1 = cljs.core.__destructure_map.call(null,map__2136);
var value = cljs.core.get.call(null,map__2136__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value)) || (cljs.core.contains_QMARK_.call(null,cljs.core.set.call(null,option_values),clojure.string.trim.call(null,(function (){var or__5142__auto____$1 = value;
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
return "";
}
})())))),new cljs.core.Keyword(null,"allowed","allowed",1436019743),cljs.core.vec.call(null,cljs.core.concat.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, ["<Blank>"], null),option_values))], null);
})], null);
} else {
if((((p_kind == null)) && ((((ref_match == null)) && (org.kp.kpmc.companion_rules.contains_angle_token_QMARK_.call(null,kp)))))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"placeholder","placeholder",-104873083),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2137){
var map__2138 = p__2137;
var map__2138__$1 = cljs.core.__destructure_map.call(null,map__2138);
var value = cljs.core.get.call(null,map__2138__$1,new cljs.core.Keyword(null,"value","value",305978217));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"required","required",1807647006))){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),(!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))),new cljs.core.Keyword(null,"expected","expected",1583670997),new cljs.core.Keyword(null,"non-blank","non-blank",-722255043)], null);
} else {
return new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"valid","valid",155614240),true], null);
}
})], null);
} else {
if(cljs.core.seq.call(null,option_values)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"enum","enum",1679018432),new cljs.core.Keyword(null,"allowed","allowed",1436019743),cljs.core.set.call(null,option_values),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2139){
var map__2140 = p__2139;
var map__2140__$1 = cljs.core.__destructure_map.call(null,map__2140);
var value = cljs.core.get.call(null,map__2140__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),org.kp.kpmc.companion_rules.enum_valid_QMARK_.call(null,new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(rule),cljs.core.set.call(null,option_values),value),new cljs.core.Keyword(null,"allowed","allowed",1436019743),option_values], null);
})], null);
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"kind","kind",-717265803),new cljs.core.Keyword(null,"literal","literal",1664775605),new cljs.core.Keyword(null,"validate","validate",-201300827),(function (p__2141){
var map__2142 = p__2141;
var map__2142__$1 = cljs.core.__destructure_map.call(null,map__2142);
var value = cljs.core.get.call(null,map__2142__$1,new cljs.core.Keyword(null,"value","value",305978217));
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core._EQ_.call(null,clojure.string.trim.call(null,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()),kp),new cljs.core.Keyword(null,"expected","expected",1583670997),kp], null);
})], null);

}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});
/**
 * Compile parsed companion model rows into executable rule maps with cljs predicates.
 */
org.kp.kpmc.companion_rules.compile_rules = (function org$kp$kpmc$companion_rules$compile_rules(model){
return cljs.core.vec.call(null,cljs.core.filter.call(null,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),cljs.core.map.call(null,(function (e){
var map__2143 = (function (){var or__5142__auto__ = org.kp.kpmc.companion.parse_segment_ref.call(null,new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(e));
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
})();
var map__2143__$1 = cljs.core.__destructure_map.call(null,map__2143);
var segment_id = cljs.core.get.call(null,map__2143__$1,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590));
var position = cljs.core.get.call(null,map__2143__$1,new cljs.core.Keyword(null,"position","position",-2011731912));
var pred = org.kp.kpmc.companion_rules.build_rule_predicate.call(null,e);
return cljs.core.merge.call(null,cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"loop-name","loop-name",468086403),new cljs.core.Keyword(null,"kp-element","kp-element",1092855431),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482),new cljs.core.Keyword(null,"rule-id","rule-id",426305841),new cljs.core.Keyword(null,"usage","usage",-1583752910),new cljs.core.Keyword(null,"segment-requirement","segment-requirement",-1307113229),new cljs.core.Keyword(null,"label","label",1718410804),new cljs.core.Keyword(null,"segment-description","segment-description",-1183758987),new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),new cljs.core.Keyword(null,"position","position",-2011731912),new cljs.core.Keyword(null,"options","options",99638489),new cljs.core.Keyword(null,"element-description","element-description",1941111197)],[cljs.core.get_in.call(null,e,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop","loop",-395552849),new cljs.core.Keyword(null,"loop-name","loop-name",468086403)], null)),new cljs.core.Keyword(null,"kp-element","kp-element",1092855431).cljs$core$IFn$_invoke$arity$1(e),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(e),(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto__ = segment_id;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "UNK";
}
})())+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto__ = org.kp.kpmc.companion_rules.zero_pad2.call(null,(function (){var or__5142__auto__ = position;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return (0);
}
})());
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "00";
}
})())),new cljs.core.Keyword(null,"usage","usage",-1583752910).cljs$core$IFn$_invoke$arity$1(e),cljs.core.get_in.call(null,e,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop","loop",-395552849),new cljs.core.Keyword(null,"segment-requirement","segment-requirement",-1307113229)], null)),new cljs.core.Keyword(null,"label","label",1718410804).cljs$core$IFn$_invoke$arity$1(e),cljs.core.get_in.call(null,e,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop","loop",-395552849),new cljs.core.Keyword(null,"segment-description","segment-description",-1183758987)], null)),segment_id,position,new cljs.core.Keyword(null,"options","options",99638489).cljs$core$IFn$_invoke$arity$1(e),new cljs.core.Keyword(null,"element-description","element-description",1941111197).cljs$core$IFn$_invoke$arity$1(e)]),pred);
}),new cljs.core.Keyword(null,"elements","elements",657646735).cljs$core$IFn$_invoke$arity$1(model))));
});
org.kp.kpmc.companion_rules.parse_companion_csv__GT_rules = (function org$kp$kpmc$companion_rules$parse_companion_csv__GT_rules(csv_file){
cljs.core.println.call(null,"[parse-companion-csv->rules]");

var text = org.kp.kpmc.io_node.read_text.call(null,csv_file);
var model = org.kp.kpmc.companion_rules.parse_companion_csv__GT_model.call(null,text);
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"model","model",331153215),model,new cljs.core.Keyword(null,"rules","rules",1198912366),org.kp.kpmc.companion_rules.compile_rules.call(null,model)], null);
});
org.kp.kpmc.companion_rules.to_ref = (function org$kp$kpmc$companion_rules$to_ref(segment_id,position){
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(segment_id)+cljs.core.str.cljs$core$IFn$_invoke$arity$1(org.kp.kpmc.companion_rules.zero_pad2.call(null,position)));
});
org.kp.kpmc.companion_rules.extract_seg_id = (function org$kp$kpmc$companion_rules$extract_seg_id(data_segment_node){
return cljs.core.some.call(null,(function (child){
if(org.kp.kpmc.companion_rules.tag_EQ_.call(null,child,"seg_id")){
return cljs.core.second.call(null,child);
} else {
return null;
}
}),cljs.core.rest.call(null,data_segment_node));
});
org.kp.kpmc.companion_rules.extract_unit_values = (function org$kp$kpmc$companion_rules$extract_unit_values(data_segment_node){
return cljs.core.vec.call(null,cljs.core.map.call(null,(function (unit){
var second_val = cljs.core.second.call(null,unit);
if(cljs.core.map_QMARK_.call(null,second_val)){
return cljs.core.nth.call(null,unit,(2),null);
} else {
return second_val;
}
}),cljs.core.filter.call(null,(function (p1__2144_SHARP_){
return org.kp.kpmc.companion_rules.tag_EQ_.call(null,p1__2144_SHARP_,"data_segment_unit");
}),cljs.core.rest.call(null,data_segment_node))));
});
org.kp.kpmc.companion_rules.annotate_unit = (function org$kp$kpmc$companion_rules$annotate_unit(unit,annotation){
var second_val = cljs.core.second.call(null,unit);
if(cljs.core.map_QMARK_.call(null,second_val)){
var val = cljs.core.nth.call(null,unit,(2),null);
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,unit),cljs.core.merge.call(null,second_val,annotation),val], null);
} else {
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,unit),annotation,second_val], null);
}
});
/**
 * Split raw segment text into [segment-id values].
 */
org.kp.kpmc.companion_rules.split_raw_segment = (function org$kp$kpmc$companion_rules$split_raw_segment(raw){
var parts = clojure.string.split.call(null,(function (){var or__5142__auto__ = raw;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})(),/\*/,(-1));
var seg_id = cljs.core.first.call(null,parts);
var values = cljs.core.vec.call(null,cljs.core.rest.call(null,parts));
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [seg_id,values], null);
});
org.kp.kpmc.companion_rules.safe_read_edn = (function org$kp$kpmc$companion_rules$safe_read_edn(text){
try{return cljs.reader.read_string.call(null,text);
}catch (e2145){var _ = e2145;
return null;
}});
org.kp.kpmc.companion_rules.safe_read_json = (function org$kp$kpmc$companion_rules$safe_read_json(text){
try{return cljs.core.js__GT_clj.call(null,JSON.parse(text),new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true);
}catch (e2146){var _ = e2146;
return null;
}});
org.kp.kpmc.companion_rules.env_get = (function org$kp$kpmc$companion_rules$env_get(k){
return (process.env[k]);
});
/**
 * Canonicalize SSN to digits-only for binds and in-memory state.
 */
org.kp.kpmc.companion_rules.normalize_ssn = (function org$kp$kpmc$companion_rules$normalize_ssn(s){
return clojure.string.replace.call(null,clojure.string.trim.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto__ = s;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()))),/\D/,"");
});
org.kp.kpmc.companion_rules.resolve_env_name = (function org$kp$kpmc$companion_rules$resolve_env_name(opts){
var or__5142__auto__ = new cljs.core.Keyword(null,"env-name","env-name",1998966009).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
var or__5142__auto____$1 = new cljs.core.Keyword(null,"envName","envName",-1555267237).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
var or__5142__auto____$2 = org.kp.kpmc.companion_rules.env_get.call(null,"envName");
if(cljs.core.truth_(or__5142__auto____$2)){
return or__5142__auto____$2;
} else {
return org.kp.kpmc.companion_rules.env_get.call(null,"ENV_NAME");
}
}
}
});
org.kp.kpmc.companion_rules.db_env_keys = (function org$kp$kpmc$companion_rules$db_env_keys(env_name){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"user-key","user-key",628459277),(""+"host."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(env_name)+"-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.user"),new cljs.core.Keyword(null,"password-key","password-key",-274998740),(""+"host."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(env_name)+"-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.password"),new cljs.core.Keyword(null,"url-key","url-key",-154120626),(""+"host."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(env_name)+"-aiportal-web-2.aisvc.aksnp.azure.kp.org.datahub.url")], null);
});
org.kp.kpmc.companion_rules.resolve_db_config = (function org$kp$kpmc$companion_rules$resolve_db_config(opts){
var env_name = org.kp.kpmc.companion_rules.resolve_env_name.call(null,opts);
if(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,env_name)){
return null;
} else {
var map__2147 = org.kp.kpmc.companion_rules.db_env_keys.call(null,env_name);
var map__2147__$1 = cljs.core.__destructure_map.call(null,map__2147);
var user_key = cljs.core.get.call(null,map__2147__$1,new cljs.core.Keyword(null,"user-key","user-key",628459277));
var password_key = cljs.core.get.call(null,map__2147__$1,new cljs.core.Keyword(null,"password-key","password-key",-274998740));
var url_key = cljs.core.get.call(null,map__2147__$1,new cljs.core.Keyword(null,"url-key","url-key",-154120626));
var user = org.kp.kpmc.companion_rules.env_get.call(null,user_key);
var password = org.kp.kpmc.companion_rules.env_get.call(null,password_key);
var connect_string = org.kp.kpmc.companion_rules.env_get.call(null,url_key);
return new cljs.core.PersistentArrayMap(null, 8, [new cljs.core.Keyword(null,"env-name","env-name",1998966009),env_name,new cljs.core.Keyword(null,"user-key","user-key",628459277),user_key,new cljs.core.Keyword(null,"password-key","password-key",-274998740),password_key,new cljs.core.Keyword(null,"url-key","url-key",-154120626),url_key,new cljs.core.Keyword(null,"user","user",1532431356),user,new cljs.core.Keyword(null,"password","password",417022471),password,new cljs.core.Keyword(null,"connect-string","connect-string",1883795257),connect_string,new cljs.core.Keyword(null,"valid?","valid?",-212412379),(((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,user)))) && ((((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,password)))) && ((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,connect_string)))))))], null);
}
});
/**
 * Default to subscriber-only DB validation unless explicitly disabled.
 * Accepts opts flag or env var SUBSCRIBER_ONLY_DB_VALIDATION=false.
 */
org.kp.kpmc.companion_rules.resolve_subscriber_only_db_validation_QMARK_ = (function org$kp$kpmc$companion_rules$resolve_subscriber_only_db_validation_QMARK_(opts){
var raw = (function (){var or__5142__auto__ = new cljs.core.Keyword(null,"subscriber-only-db-validation?","subscriber-only-db-validation?",511213543).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
var or__5142__auto____$1 = new cljs.core.Keyword(null,"subscriberOnlyDbValidation","subscriberOnlyDbValidation",608166416).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
var or__5142__auto____$2 = org.kp.kpmc.companion_rules.env_get.call(null,"SUBSCRIBER_ONLY_DB_VALIDATION");
if(cljs.core.truth_(or__5142__auto____$2)){
return or__5142__auto____$2;
} else {
return true;
}
}
}
})();
var v = ((typeof raw === 'string')?clojure.string.lower_case.call(null,clojure.string.trim.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(raw)))):raw);
if(cljs.core.boolean_QMARK_.call(null,v)){
return v;
} else {
if(typeof v === 'string'){
return (!(cljs.core.contains_QMARK_.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 4, ["n",null,"false",null,"0",null,"no",null], null), null),v)));
} else {
return true;

}
}
});
org.kp.kpmc.companion_rules.loop_name__GT_scope = (function org$kp$kpmc$companion_rules$loop_name__GT_scope(loop_name){
var v = clojure.string.trim.call(null,(function (){var or__5142__auto__ = loop_name;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
if(((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,v)) || (((cljs.core._EQ_.call(null,v,"Header")) || (clojure.string.starts_with_QMARK_.call(null,v,"1000")))))){
return new cljs.core.Keyword(null,"commercial","commercial",-988961312);
} else {
if(cljs.core.truth_(cljs.core.re_matches.call(null,/^[2-9].*/,v))){
return new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413);
} else {
return new cljs.core.Keyword(null,"commercial","commercial",-988961312);

}
}
});
org.kp.kpmc.companion_rules.ensure_current_subscriber = (function org$kp$kpmc$companion_rules$ensure_current_subscriber(db_state_STAR_){
var cur = new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038).cljs$core$IFn$_invoke$arity$1(cljs.core.deref.call(null,db_state_STAR_));
if((cur == null)){
return cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc,new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"index","index",-1531685915),(1),new cljs.core.Keyword(null,"ssn","ssn",1659668683),null,new cljs.core.Keyword(null,"refs","refs",-1560051448),cljs.core.PersistentArrayMap.EMPTY], null));
} else {
return null;
}
});
org.kp.kpmc.companion_rules.start_new_subscriber_BANG_ = (function org$kp$kpmc$companion_rules$start_new_subscriber_BANG_(db_state_STAR_){
var map__2148 = cljs.core.deref.call(null,db_state_STAR_);
var map__2148__$1 = cljs.core.__destructure_map.call(null,map__2148);
var current_subscriber = cljs.core.get.call(null,map__2148__$1,new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038));
var subscribers = cljs.core.get.call(null,map__2148__$1,new cljs.core.Keyword(null,"subscribers","subscribers",-606401562));
var persisted = (cljs.core.truth_((function (){var and__5140__auto__ = current_subscriber;
if(cljs.core.truth_(and__5140__auto__)){
return (((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,new cljs.core.Keyword(null,"ssn","ssn",1659668683).cljs$core$IFn$_invoke$arity$1(current_subscriber))))) || (cljs.core.seq.call(null,new cljs.core.Keyword(null,"refs","refs",-1560051448).cljs$core$IFn$_invoke$arity$1(current_subscriber))));
} else {
return and__5140__auto__;
}
})())?cljs.core.conj.call(null,subscribers,current_subscriber):subscribers);
var next_index = (cljs.core.count.call(null,persisted) + (1));
return cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc,new cljs.core.Keyword(null,"subscribers","subscribers",-606401562),persisted,new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"index","index",-1531685915),next_index,new cljs.core.Keyword(null,"ssn","ssn",1659668683),null,new cljs.core.Keyword(null,"refs","refs",-1560051448),cljs.core.PersistentArrayMap.EMPTY], null));
});
org.kp.kpmc.companion_rules.maybe_capture_subscriber_ssn_BANG_ = (function org$kp$kpmc$companion_rules$maybe_capture_subscriber_ssn_BANG_(db_state_STAR_,context,seg_id,position,value){
org.kp.kpmc.companion_rules.ensure_current_subscriber.call(null,db_state_STAR_);

var v = clojure.string.trim.call(null,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
var ssn = org.kp.kpmc.companion_rules.normalize_ssn.call(null,v);
if(cljs.core.truth_((function (){var and__5140__auto__ = cljs.core._EQ_.call(null,seg_id,"REF");
if(and__5140__auto__){
var and__5140__auto____$1 = cljs.core._EQ_.call(null,position,(2));
if(and__5140__auto____$1){
var and__5140__auto____$2 = cljs.core._EQ_.call(null,clojure.string.trim.call(null,(function (){var or__5142__auto__ = cljs.core.get.call(null,context,"REF01");
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()),"0F");
if(and__5140__auto____$2){
return cljs.core.re_matches.call(null,/\d{9}/,ssn);
} else {
return and__5140__auto____$2;
}
} else {
return and__5140__auto____$1;
}
} else {
return and__5140__auto__;
}
})())){
return cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.Keyword(null,"ssn","ssn",1659668683)], null),ssn);
} else {
if(cljs.core.truth_((function (){var and__5140__auto__ = cljs.core._EQ_.call(null,seg_id,"NM1");
if(and__5140__auto__){
var and__5140__auto____$1 = cljs.core._EQ_.call(null,position,(9));
if(and__5140__auto____$1){
var and__5140__auto____$2 = cljs.core._EQ_.call(null,clojure.string.trim.call(null,(function (){var or__5142__auto__ = cljs.core.get.call(null,context,"NM108");
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()),"34");
if(and__5140__auto____$2){
var and__5140__auto____$3 = cljs.core.re_matches.call(null,/\d{9}/,ssn);
if(cljs.core.truth_(and__5140__auto____$3)){
return org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,cljs.core.get_in.call(null,cljs.core.deref.call(null,db_state_STAR_),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.Keyword(null,"ssn","ssn",1659668683)], null)));
} else {
return and__5140__auto____$3;
}
} else {
return and__5140__auto____$2;
}
} else {
return and__5140__auto____$1;
}
} else {
return and__5140__auto__;
}
})())){
return cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.Keyword(null,"ssn","ssn",1659668683)], null),ssn);
} else {
return null;

}
}
});
org.kp.kpmc.companion_rules.update_db_state_BANG_ = (function org$kp$kpmc$companion_rules$update_db_state_BANG_(db_state_STAR_,context,rule,seg_id,position,value){
var ref = org.kp.kpmc.companion_rules.to_ref.call(null,seg_id,position);
var scope = org.kp.kpmc.companion_rules.loop_name__GT_scope.call(null,new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(rule));
var v = clojure.string.trim.call(null,(function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})());
if(((cljs.core._EQ_.call(null,seg_id,"INS")) && (cljs.core._EQ_.call(null,position,(1))))){
org.kp.kpmc.companion_rules.start_new_subscriber_BANG_.call(null,db_state_STAR_);
} else {
}

if(cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413))){
org.kp.kpmc.companion_rules.ensure_current_subscriber.call(null,db_state_STAR_);
} else {
}

if((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,v)))){
if(cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"commercial","commercial",-988961312))){
cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"commercial-refs","commercial-refs",508899454),ref], null),value);
} else {
cljs.core.swap_BANG_.call(null,db_state_STAR_,cljs.core.assoc_in,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),new cljs.core.Keyword(null,"refs","refs",-1560051448),ref], null),value);
}
} else {
}

return org.kp.kpmc.companion_rules.maybe_capture_subscriber_ssn_BANG_.call(null,db_state_STAR_,context,seg_id,position,value);
});
org.kp.kpmc.companion_rules.current_db_context = (function org$kp$kpmc$companion_rules$current_db_context(db_state_STAR_,rule){
var scope = org.kp.kpmc.companion_rules.loop_name__GT_scope.call(null,new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(rule));
var state = cljs.core.deref.call(null,db_state_STAR_);
if(cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"commercial","commercial",-988961312))){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"scope","scope",-439358418),new cljs.core.Keyword(null,"commercial","commercial",-988961312),new cljs.core.Keyword(null,"subscriber-index","subscriber-index",326386903),null,new cljs.core.Keyword(null,"subscriber-ssn","subscriber-ssn",-1013411620),null,new cljs.core.Keyword(null,"refs","refs",-1560051448),new cljs.core.Keyword(null,"commercial-refs","commercial-refs",508899454).cljs$core$IFn$_invoke$arity$1(state)], null);
} else {
var cur = new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038).cljs$core$IFn$_invoke$arity$1(state);
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"scope","scope",-439358418),new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413),new cljs.core.Keyword(null,"subscriber-index","subscriber-index",326386903),new cljs.core.Keyword(null,"index","index",-1531685915).cljs$core$IFn$_invoke$arity$1(cur),new cljs.core.Keyword(null,"subscriber-ssn","subscriber-ssn",-1013411620),new cljs.core.Keyword(null,"ssn","ssn",1659668683).cljs$core$IFn$_invoke$arity$1(cur),new cljs.core.Keyword(null,"refs","refs",-1560051448),new cljs.core.Keyword(null,"refs","refs",-1560051448).cljs$core$IFn$_invoke$arity$1(cur)], null);
}
});
org.kp.kpmc.companion_rules.execute_oracle_query_sync = (function org$kp$kpmc$companion_rules$execute_oracle_query_sync(db_config,sql,binds){
var child_proc = require("child_process");
var script = (""+"const oracledb=require('oracledb');"+"(async()=>{"+"const p=JSON.parse(process.argv[1]);"+"let conn=null;"+"try{"+"conn=await oracledb.getConnection({user:p.user,password:p.password,connectString:p.connectString});"+"const r=await conn.execute(p.sql,p.binds,{outFormat:oracledb.OUT_FORMAT_OBJECT});"+"const rows=r.rows||[];"+"const row=rows[0]||null;"+"const hit=(row&&(row.HIT_COUNT??row.hit_count))!=null?Number(row.HIT_COUNT??row.hit_count):rows.length;"+"console.log(JSON.stringify({ok:true,hitCount:hit,rowCount:rows.length,row:row}));"+"}catch(e){"+"console.log(JSON.stringify({ok:false,error:e&&e.message?e.message:String(e),code:e&&e.code?e.code:null,errorNum:e&&e.errorNum?e.errorNum:null}));"+"}finally{if(conn){try{await conn.close();}catch(_){}}}"+"})();");
var payload = JSON.stringify(cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"user","user",1532431356),new cljs.core.Keyword(null,"user","user",1532431356).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"password","password",417022471),new cljs.core.Keyword(null,"password","password",417022471).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"connectString","connectString",551823639),new cljs.core.Keyword(null,"connect-string","connect-string",1883795257).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"sql","sql",1251448786),sql,new cljs.core.Keyword(null,"binds","binds",363649660),binds], null)));
try{var out = child_proc.execFileSync("node",cljs.core.clj__GT_js.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, ["-e",script,payload], null)),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"encoding","encoding",1728578272),"utf8"], null)));
var or__5142__auto__ = org.kp.kpmc.companion_rules.safe_read_json.call(null,out);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"ok","ok",967785236),false,new cljs.core.Keyword(null,"error","error",-978969032),new cljs.core.Keyword(null,"invalid-db-response","invalid-db-response",1536370188)], null);
}
}catch (e2149){var e = e2149;
var stdout = (function (){var G__2150 = e;
var G__2150__$1 = (((G__2150 == null))?null:G__2150.stdout);
if((G__2150__$1 == null)){
return null;
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__2150__$1));
}
})();
var stderr = (function (){var G__2151 = e;
var G__2151__$1 = (((G__2151 == null))?null:G__2151.stderr);
if((G__2151__$1 == null)){
return null;
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(G__2151__$1));
}
})();
var parsed_out = org.kp.kpmc.companion_rules.safe_read_json.call(null,stdout);
var parsed_err = org.kp.kpmc.companion_rules.safe_read_json.call(null,stderr);
var or__5142__auto__ = ((cljs.core.map_QMARK_.call(null,parsed_out))?parsed_out:null);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
var or__5142__auto____$1 = ((cljs.core.map_QMARK_.call(null,parsed_err))?parsed_err:null);
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"ok","ok",967785236),false,new cljs.core.Keyword(null,"error","error",-978969032),(function (){var or__5142__auto____$2 = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,stdout))?null:stdout);
if(cljs.core.truth_(or__5142__auto____$2)){
return or__5142__auto____$2;
} else {
var or__5142__auto____$3 = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,stderr))?null:stderr);
if(cljs.core.truth_(or__5142__auto____$3)){
return or__5142__auto____$3;
} else {
var or__5142__auto____$4 = e.message;
if(cljs.core.truth_(or__5142__auto____$4)){
return or__5142__auto____$4;
} else {
return new cljs.core.Keyword(null,"db-exec-failed","db-exec-failed",-1546162415);
}
}
}
})()], null);
}
}
}});
/**
 * Build SSN-anchored subscriber validation SQL for a mapped table/column.
 *       Returns nil when table strategy is not yet defined.
 */
org.kp.kpmc.companion_rules.subscriber_sql_by_table = (function org$kp$kpmc$companion_rules$subscriber_sql_by_table(table,column){
var person_child = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 5, ["TAP_PERSON_EMAIL",null,"TAP_PERSON_LANGUAGE",null,"TAP_PERSON_PHONE",null,"TAP_PERSON_EXTERNAL_IDENTIFIER",null,"TAP_PERSON_ADDRESS",null], null), null);
var person_coverage_child = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 6, ["TAP_PERSON_COVERAGE_RIDER",null,"TAP_PERSON_COVERAGE_AFFILIATION",null,"TAP_PERSON_COVERAGE_ATTRIBUTE",null,"TAP_PERSON_COVERAGE_PREMIUM_RATE",null,"TAP_PERSON_COVERAGE_ADDRESS",null,"TAP_PERSON_COVERAGE_AFFILIATION_COMM",null], null), null);
var ssn_expr = "replace(replace(c.SUBSCRIBER_SSN, '-', ''), ' ', '')";
if(cljs.core._EQ_.call(null,table,"TAP_COVERAGE")){
return (""+"select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_COVERAGE c "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(((cljs.core._EQ_.call(null,column,"SUBSCRIBER_SSN"))?"replace(replace(c.SUBSCRIBER_SSN, '-', ''), ' ', '')":(""+"c."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column))))+" = :value");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_PERSON")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "+"join MEMBER_OWNER.TAP_PERSON p on p.PERSON_ID = pc.PERSON_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and p."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_PERSON_COVERAGE")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and pc."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
if(cljs.core.contains_QMARK_.call(null,person_child,table)){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "+"join MEMBER_OWNER."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(table)+" t on t.PERSON_ID = pc.PERSON_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and t."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
if(cljs.core.contains_QMARK_.call(null,person_coverage_child,table)){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_PERSON_COVERAGE pc on pc.COVERAGE_ID = c.COVERAGE_ID "+"join MEMBER_OWNER."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(table)+" t on t.PERSON_ID = pc.PERSON_ID and t.COVERAGE_ID = pc.COVERAGE_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and t."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_PLAN_GROUP")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_PLAN_GROUP pg on pg.PLAN_GROUP_ID = c.PLAN_GROUP_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and pg."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_STAGING_COMPANION")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_STAGING_COMPANION sc "+"where sc."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value and exists ("+"select 1 from MEMBER_OWNER.TAP_COVERAGE c "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and ("+"c.COVERAGE_ID = sc.SPECIFIED_COVERAGE_ID or "+"c.COVERAGE_ID = sc.ELIG_COVERAGE_ID or "+"c.COVERAGE_ID = sc.ELIG_SOURCE_COVERAGE_ID or "+"c.COVERAGE_ID = sc.PRIMARY_COVERAGE_ID"+"))");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_BENEFIT_PLAN")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_STAGING_COMPANION sc "+"join MEMBER_OWNER.TAP_BENEFIT_PLAN bp on bp.BENEFIT_PLAN_ID = sc.BENEFIT_PLAN_ID "+"where bp."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value and exists ("+"select 1 from MEMBER_OWNER.TAP_COVERAGE c "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and ("+"c.COVERAGE_ID = sc.SPECIFIED_COVERAGE_ID or "+"c.COVERAGE_ID = sc.ELIG_COVERAGE_ID or "+"c.COVERAGE_ID = sc.ELIG_SOURCE_COVERAGE_ID or "+"c.COVERAGE_ID = sc.PRIMARY_COVERAGE_ID"+"))");
} else {
if(cljs.core._EQ_.call(null,table,"TAP_COVERAGE_THIRD_PARTY_PAYER")){
return (""+"select count(*) as HIT_COUNT "+"from MEMBER_OWNER.TAP_COVERAGE c "+"join MEMBER_OWNER.TAP_COVERAGE_THIRD_PARTY_PAYER tpp on tpp.COVERAGE_ID = c.COVERAGE_ID "+"where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(ssn_expr)+" = :ssn and tpp."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value");
} else {
return null;

}
}
}
}
}
}
}
}
}
});
org.kp.kpmc.companion_rules.make_oracle_lookup_executor = (function org$kp$kpmc$companion_rules$make_oracle_lookup_executor(opts){
var db_config = org.kp.kpmc.companion_rules.resolve_db_config.call(null,opts);
var subscriber_only_QMARK_ = org.kp.kpmc.companion_rules.resolve_subscriber_only_db_validation_QMARK_.call(null,opts);
return (function (p__2152){
var map__2153 = p__2152;
var map__2153__$1 = cljs.core.__destructure_map.call(null,map__2153);
var spec = cljs.core.get.call(null,map__2153__$1,new cljs.core.Keyword(null,"spec","spec",347520401));
var value = cljs.core.get.call(null,map__2153__$1,new cljs.core.Keyword(null,"value","value",305978217));
var db_context = cljs.core.get.call(null,map__2153__$1,new cljs.core.Keyword(null,"db-context","db-context",371097239));
var scope = new cljs.core.Keyword(null,"scope","scope",-439358418).cljs$core$IFn$_invoke$arity$1(db_context);
var ssn = new cljs.core.Keyword(null,"subscriber-ssn","subscriber-ssn",-1013411620).cljs$core$IFn$_invoke$arity$1(db_context);
var normalized_ssn = org.kp.kpmc.companion_rules.normalize_ssn.call(null,ssn);
var table = new cljs.core.Keyword(null,"table","table",-564943036).cljs$core$IFn$_invoke$arity$1(spec);
var column = new cljs.core.Keyword(null,"column","column",2078222095).cljs$core$IFn$_invoke$arity$1(spec);
var segment_ref = new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(spec);
var text_value = (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto__ = value;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})()));
var normalized_value = ((cljs.core._EQ_.call(null,column,"SUBSCRIBER_SSN"))?org.kp.kpmc.companion_rules.normalize_ssn.call(null,text_value):value);
var subscriber_sql = org.kp.kpmc.companion_rules.subscriber_sql_by_table.call(null,table,column);
var commercial_query = ((((cljs.core._EQ_.call(null,table,"TAP_STAGING_COMPANION")) && (cljs.core._EQ_.call(null,column,"APPLICATION_TIMESTAMP"))))?((((cljs.core._EQ_.call(null,segment_ref,"BGN03")) && (cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{8}/,text_value)))))?new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"sql","sql",1251448786),"select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'YYYYMMDD') = :value",new cljs.core.Keyword(null,"binds","binds",363649660),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"value","value",305978217),text_value], null))], null):((((cljs.core._EQ_.call(null,segment_ref,"BGN04")) && (cljs.core.boolean$.call(null,cljs.core.re_matches.call(null,/\d{6,8}/,text_value)))))?new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"sql","sql",1251448786),"select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'HH24MISS') = :value",new cljs.core.Keyword(null,"binds","binds",363649660),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"value","value",305978217),cljs.core.subs.call(null,text_value,(0),(6))], null))], null):new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"sql","sql",1251448786),"select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_STAGING_COMPANION where to_char(APPLICATION_TIMESTAMP, 'YYYYMMDDHH24MISS') = :value",new cljs.core.Keyword(null,"binds","binds",363649660),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"value","value",305978217),text_value], null))], null)
)):((((cljs.core._EQ_.call(null,table,"TAP_COVERAGE")) && (cljs.core._EQ_.call(null,column,"SUBSCRIBER_SSN"))))?new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"sql","sql",1251448786),"select count(*) as HIT_COUNT from MEMBER_OWNER.TAP_COVERAGE where replace(replace(SUBSCRIBER_SSN, '-', ''), ' ', '') = :value",new cljs.core.Keyword(null,"binds","binds",363649660),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"value","value",305978217),org.kp.kpmc.companion_rules.normalize_ssn.call(null,text_value)], null))], null):new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"sql","sql",1251448786),(""+"select count(*) as HIT_COUNT from MEMBER_OWNER."+cljs.core.str.cljs$core$IFn$_invoke$arity$1(table)+" where "+cljs.core.str.cljs$core$IFn$_invoke$arity$1(column)+" = :value"),new cljs.core.Keyword(null,"binds","binds",363649660),cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"value","value",305978217),value], null))], null)));
var sql = ((cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413)))?subscriber_sql:new cljs.core.Keyword(null,"sql","sql",1251448786).cljs$core$IFn$_invoke$arity$1(commercial_query));
if((db_config == null)){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),false,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"db-config-missing","db-config-missing",1152491708),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"missing-env-name","missing-env-name",963723770)], null);
} else {
if(cljs.core.not.call(null,new cljs.core.Keyword(null,"valid?","valid?",-212412379).cljs$core$IFn$_invoke$arity$1(db_config))){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),false,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"db-config-invalid","db-config-invalid",-973365429),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"env-name","env-name",1998966009),new cljs.core.Keyword(null,"env-name","env-name",1998966009).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"user-key","user-key",628459277),new cljs.core.Keyword(null,"user-key","user-key",628459277).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"password-key","password-key",-274998740),new cljs.core.Keyword(null,"password-key","password-key",-274998740).cljs$core$IFn$_invoke$arity$1(db_config),new cljs.core.Keyword(null,"url-key","url-key",-154120626),new cljs.core.Keyword(null,"url-key","url-key",-154120626).cljs$core$IFn$_invoke$arity$1(db_config)], null)], null);
} else {
if(((subscriber_only_QMARK_) && (cljs.core.not_EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413))))){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"skipped-non-subscriber-scope","skipped-non-subscriber-scope",-135438847),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"subscriber-only-db-validation","subscriber-only-db-validation",-1375507702)], null);
} else {
if(((cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413))) && (cljs.core.not.call(null,cljs.core.re_matches.call(null,/\d{9}/,normalized_ssn))))){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"missing-subscriber-ssn","missing-subscriber-ssn",-526376865),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"subscriber-lookups-require-ssn","subscriber-lookups-require-ssn",-743362013)], null);
} else {
if(((cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413))) && ((sql == null)))){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"skipped-unmapped-subscriber-attribute","skipped-unmapped-subscriber-attribute",-640602570),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"table","table",-564943036),table,new cljs.core.Keyword(null,"column","column",2078222095),column], null)], null);
} else {
var binds = ((cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413)))?cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"value","value",305978217),normalized_value,new cljs.core.Keyword(null,"ssn","ssn",1659668683),normalized_ssn], null)):new cljs.core.Keyword(null,"binds","binds",363649660).cljs$core$IFn$_invoke$arity$1(commercial_query));
var q = org.kp.kpmc.companion_rules.execute_oracle_query_sync.call(null,db_config,sql,binds);
var hit = (function (){var or__5142__auto__ = new cljs.core.Keyword(null,"hitCount","hitCount",1989188482).cljs$core$IFn$_invoke$arity$1(q);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return (0);
}
})();
var ok_QMARK_ = (function (){var and__5140__auto__ = new cljs.core.Keyword(null,"ok","ok",967785236).cljs$core$IFn$_invoke$arity$1(q);
if(cljs.core.truth_(and__5140__auto__)){
return (hit > (0));
} else {
return and__5140__auto__;
}
})();
return new cljs.core.PersistentArrayMap(null, 8, [new cljs.core.Keyword(null,"executed?","executed?",802143904),true,new cljs.core.Keyword(null,"valid","valid",155614240),cljs.core.boolean$.call(null,ok_QMARK_),new cljs.core.Keyword(null,"status","status",-1997798413),(cljs.core.truth_(new cljs.core.Keyword(null,"ok","ok",967785236).cljs$core$IFn$_invoke$arity$1(q))?(cljs.core.truth_(ok_QMARK_)?new cljs.core.Keyword(null,"db-hit","db-hit",-1530306888):new cljs.core.Keyword(null,"db-miss","db-miss",88930419)):new cljs.core.Keyword(null,"db-error","db-error",592028563)),new cljs.core.Keyword(null,"hit-count","hit-count",400844304),hit,new cljs.core.Keyword(null,"scope","scope",-439358418),scope,new cljs.core.Keyword(null,"subscriber-ssn","subscriber-ssn",-1013411620),((cljs.core._EQ_.call(null,scope,new cljs.core.Keyword(null,"subscriber","subscriber",-2064338413)))?normalized_ssn:null),new cljs.core.Keyword(null,"reason","reason",-2070751759),(cljs.core.truth_(new cljs.core.Keyword(null,"ok","ok",967785236).cljs$core$IFn$_invoke$arity$1(q))?null:new cljs.core.Keyword(null,"error","error",-978969032).cljs$core$IFn$_invoke$arity$1(q)),new cljs.core.Keyword(null,"sql","sql",1251448786),sql], null);

}
}
}
}
}
});
});
/**
 * Load generated lookup specs EDN. Returns nil when file cannot be read/parsed.
 */
org.kp.kpmc.companion_rules.load_lookup_specs = (function org$kp$kpmc$companion_rules$load_lookup_specs(lookup_spec_file){
try{var G__2155 = lookup_spec_file;
var G__2155__$1 = (((G__2155 == null))?null:org.kp.kpmc.io_node.read_text.call(null,G__2155));
if((G__2155__$1 == null)){
return null;
} else {
return org.kp.kpmc.companion_rules.safe_read_edn.call(null,G__2155__$1);
}
}catch (e2154){var _ = e2154;
return null;
}});
/**
 * Build a lookup index keyed by [loop segment-id segment-ref].
 */
org.kp.kpmc.companion_rules.build_lookup_index = (function org$kp$kpmc$companion_rules$build_lookup_index(lookup_doc){
var specs = new cljs.core.Keyword(null,"specs","specs",1426570741).cljs$core$IFn$_invoke$arity$1(lookup_doc);
return cljs.core.reduce.call(null,(function (acc,spec){
var k = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop","loop",-395552849).cljs$core$IFn$_invoke$arity$1(spec),new cljs.core.Keyword(null,"segment-id","segment-id",1810133590).cljs$core$IFn$_invoke$arity$1(spec),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(spec)], null);
return cljs.core.assoc.call(null,acc,k,spec);
}),cljs.core.PersistentArrayMap.EMPTY,specs);
});
/**
 * Resolve best lookup spec for a rule. Prefer exact loop match, fallback to segment+ref match.
 */
org.kp.kpmc.companion_rules.find_lookup_spec = (function org$kp$kpmc$companion_rules$find_lookup_spec(lookup_index,rule){
var exact_k = new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"segment-id","segment-id",1810133590).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(rule)], null);
var exact = cljs.core.get.call(null,lookup_index,exact_k);
if(cljs.core.truth_(exact)){
return exact;
} else {
return cljs.core.some.call(null,(function (p__2156){
var vec__2157 = p__2156;
var vec__2160 = cljs.core.nth.call(null,vec__2157,(0),null);
var _loop = cljs.core.nth.call(null,vec__2160,(0),null);
var seg = cljs.core.nth.call(null,vec__2160,(1),null);
var ref = cljs.core.nth.call(null,vec__2160,(2),null);
var spec = cljs.core.nth.call(null,vec__2157,(1),null);
if(((cljs.core._EQ_.call(null,seg,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590).cljs$core$IFn$_invoke$arity$1(rule))) && (cljs.core._EQ_.call(null,ref,new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(rule))))){
return spec;
} else {
return null;
}
}),lookup_index);
}
});
/**
 * Default executor when no DB integration is provided yet.
 */
org.kp.kpmc.companion_rules.default_lookup_executor = (function org$kp$kpmc$companion_rules$default_lookup_executor(_){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"executed?","executed?",802143904),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"not-executed","not-executed",-1602466072),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"no-db-executor-configured","no-db-executor-configured",1097165657)], null);
});
org.kp.kpmc.companion_rules.evaluate_lookup = (function org$kp$kpmc$companion_rules$evaluate_lookup(p__2163,rule,value,db_context){
var map__2164 = p__2163;
var map__2164__$1 = cljs.core.__destructure_map.call(null,map__2164);
var lookup_index = cljs.core.get.call(null,map__2164__$1,new cljs.core.Keyword(null,"lookup-index","lookup-index",-1886927582));
var lookup_executor = cljs.core.get.call(null,map__2164__$1,new cljs.core.Keyword(null,"lookup-executor","lookup-executor",-158156549));
var include_lookup_sql_QMARK_ = cljs.core.get.call(null,map__2164__$1,new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460));
if(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"skipped-blank","skipped-blank",1529224316)], null);
} else {
if((lookup_index == null)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"no-lookup-index","no-lookup-index",-1499095730)], null);
} else {
var spec = org.kp.kpmc.companion_rules.find_lookup_spec.call(null,lookup_index,rule);
if((spec == null)){
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766),false,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"no-spec","no-spec",838519238)], null);
} else {
if((!(new cljs.core.Keyword(null,"enabled?","enabled?",-1376075057).cljs$core$IFn$_invoke$arity$1(spec) === true))){
return new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766),true,new cljs.core.Keyword(null,"valid","valid",155614240),true,new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"spec-disabled","spec-disabled",-241393383),new cljs.core.Keyword(null,"lookup-spec-id","lookup-spec-id",-228094302),new cljs.core.Keyword(null,"id","id",-1388402092).cljs$core$IFn$_invoke$arity$1(spec),new cljs.core.Keyword(null,"lookup-kind","lookup-kind",-805434838),new cljs.core.Keyword(null,"lookup-kind","lookup-kind",-805434838).cljs$core$IFn$_invoke$arity$1(spec),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"disabled-reason","disabled-reason",-1615810409).cljs$core$IFn$_invoke$arity$1(spec)], null);
} else {
var exec_fn = (function (){var or__5142__auto__ = lookup_executor;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return org.kp.kpmc.companion_rules.default_lookup_executor;
}
})();
var exec_result = (function (){var or__5142__auto__ = exec_fn.call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"spec","spec",347520401),spec,new cljs.core.Keyword(null,"rule","rule",729973257),rule,new cljs.core.Keyword(null,"value","value",305978217),value,new cljs.core.Keyword(null,"db-context","db-context",371097239),db_context], null));
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
})();
var executed_QMARK_ = cljs.core.boolean$.call(null,new cljs.core.Keyword(null,"executed?","executed?",802143904).cljs$core$IFn$_invoke$arity$1(exec_result));
var lookup_valid_QMARK_ = ((cljs.core.contains_QMARK_.call(null,exec_result,new cljs.core.Keyword(null,"valid","valid",155614240)))?cljs.core.boolean$.call(null,new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(exec_result)):true);
var G__2165 = cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"valid","valid",155614240),new cljs.core.Keyword(null,"executed?","executed?",802143904),new cljs.core.Keyword(null,"lookup-spec-id","lookup-spec-id",-228094302),new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766),new cljs.core.Keyword(null,"lookup-kind","lookup-kind",-805434838),new cljs.core.Keyword(null,"scope","scope",-439358418),new cljs.core.Keyword(null,"reason","reason",-2070751759),new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"subscriber-index","subscriber-index",326386903)],[lookup_valid_QMARK_,executed_QMARK_,new cljs.core.Keyword(null,"id","id",-1388402092).cljs$core$IFn$_invoke$arity$1(spec),true,new cljs.core.Keyword(null,"lookup-kind","lookup-kind",-805434838).cljs$core$IFn$_invoke$arity$1(spec),new cljs.core.Keyword(null,"scope","scope",-439358418).cljs$core$IFn$_invoke$arity$1(db_context),new cljs.core.Keyword(null,"reason","reason",-2070751759).cljs$core$IFn$_invoke$arity$1(exec_result),(function (){var or__5142__auto__ = new cljs.core.Keyword(null,"status","status",-1997798413).cljs$core$IFn$_invoke$arity$1(exec_result);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
if(executed_QMARK_){
return new cljs.core.Keyword(null,"executed","executed",-16905121);
} else {
return new cljs.core.Keyword(null,"not-executed","not-executed",-1602466072);
}
}
})(),new cljs.core.Keyword(null,"subscriber-index","subscriber-index",326386903).cljs$core$IFn$_invoke$arity$1(db_context)]);
if(cljs.core.truth_(include_lookup_sql_QMARK_)){
return cljs.core.assoc.call(null,G__2165,new cljs.core.Keyword(null,"sql","sql",1251448786),cljs.core.get_in.call(null,spec,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"sql","sql",1251448786),new cljs.core.Keyword(null,"exists","exists",1312597120)], null)));
} else {
return G__2165;
}

}
}

}
}
});
/**
 * Run one compiled rule against a single element value and update stats/context.
 */
org.kp.kpmc.companion_rules.run_rule_on_value = (function org$kp$kpmc$companion_rules$run_rule_on_value(context_STAR_,stats_STAR_,db_state_STAR_,rule,seg_id,position,value,lookup_state){
var ref = org.kp.kpmc.companion_rules.to_ref.call(null,seg_id,position);
var _ = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))?null:cljs.core.swap_BANG_.call(null,context_STAR_,cljs.core.assoc,ref,value));
var ___$1 = org.kp.kpmc.companion_rules.update_db_state_BANG_.call(null,db_state_STAR_,cljs.core.deref.call(null,context_STAR_),rule,seg_id,position,value);
var db_context = org.kp.kpmc.companion_rules.current_db_context.call(null,db_state_STAR_,rule);
var result = new cljs.core.Keyword(null,"validate","validate",-201300827).cljs$core$IFn$_invoke$arity$1(rule).call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"value","value",305978217),value,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),seg_id,new cljs.core.Keyword(null,"position","position",-2011731912),position,new cljs.core.Keyword(null,"context","context",-830191113),cljs.core.deref.call(null,context_STAR_)], null));
var lookup_result = org.kp.kpmc.companion_rules.evaluate_lookup.call(null,lookup_state,rule,value,db_context);
var rule_valid_QMARK_ = cljs.core.boolean$.call(null,new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(result));
var valid_QMARK_ = ((rule_valid_QMARK_) && (cljs.core.boolean$.call(null,new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(lookup_result))));
var annotation = new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"rule-id","rule-id",426305841),new cljs.core.Keyword(null,"rule-id","rule-id",426305841).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"valid","valid",155614240),valid_QMARK_,new cljs.core.Keyword(null,"rule-kind","rule-kind",-1619689839),new cljs.core.Keyword(null,"kind","kind",-717265803).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"lookup","lookup",1225356838),lookup_result], null);
cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update,new cljs.core.Keyword(null,"total","total",1916810418),cljs.core.inc);

cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update,((valid_QMARK_)?new cljs.core.Keyword(null,"passed","passed",-28165278):new cljs.core.Keyword(null,"failed","failed",-1397425762)),cljs.core.inc);

if(cljs.core.truth_(new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766).cljs$core$IFn$_invoke$arity$1(lookup_result))){
cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"lookup","lookup",1225356838),new cljs.core.Keyword(null,"attempted","attempted",1101657210)], null),cljs.core.fnil.call(null,cljs.core.inc,(0)));

cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"lookup","lookup",1225356838),(cljs.core.truth_(new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(lookup_result))?new cljs.core.Keyword(null,"passed","passed",-28165278):new cljs.core.Keyword(null,"failed","failed",-1397425762))], null),cljs.core.fnil.call(null,cljs.core.inc,(0)));
} else {
}

if(cljs.core.not.call(null,new cljs.core.Keyword(null,"lookup-applied","lookup-applied",1034021766).cljs$core$IFn$_invoke$arity$1(lookup_result))){
cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"lookup","lookup",1225356838),new cljs.core.Keyword(null,"skipped","skipped",-1144887090)], null),cljs.core.fnil.call(null,cljs.core.inc,(0)));
} else {
}

cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"by-rule","by-rule",1219942905),new cljs.core.Keyword(null,"rule-id","rule-id",426305841).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"total","total",1916810418)], null),cljs.core.fnil.call(null,cljs.core.inc,(0)));

cljs.core.swap_BANG_.call(null,stats_STAR_,cljs.core.update_in,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"by-rule","by-rule",1219942905),new cljs.core.Keyword(null,"rule-id","rule-id",426305841).cljs$core$IFn$_invoke$arity$1(rule),((valid_QMARK_)?new cljs.core.Keyword(null,"passed","passed",-28165278):new cljs.core.Keyword(null,"failed","failed",-1397425762))], null),cljs.core.fnil.call(null,cljs.core.inc,(0)));

if(valid_QMARK_){
return annotation;
} else {
return cljs.core.assoc.call(null,annotation,new cljs.core.Keyword(null,"invalid-description","invalid-description",97638859),cljs.core.pr_str.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"rule","rule",729973257),result,new cljs.core.Keyword(null,"lookup","lookup",1225356838),lookup_result], null)));
}
});
/**
 * Run one rule without mutating global stats/context; returns [annotation next-context].
 */
org.kp.kpmc.companion_rules.run_rule_preview = (function org$kp$kpmc$companion_rules$run_rule_preview(context,rule,seg_id,position,value){
var ref = org.kp.kpmc.companion_rules.to_ref.call(null,seg_id,position);
var next_context = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))?context:cljs.core.assoc.call(null,context,ref,value));
var result = new cljs.core.Keyword(null,"validate","validate",-201300827).cljs$core$IFn$_invoke$arity$1(rule).call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"value","value",305978217),value,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),seg_id,new cljs.core.Keyword(null,"position","position",-2011731912),position,new cljs.core.Keyword(null,"context","context",-830191113),next_context], null));
var valid_QMARK_ = cljs.core.boolean$.call(null,new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(result));
var annotation = (function (){var G__2166 = new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"rule-id","rule-id",426305841),new cljs.core.Keyword(null,"rule-id","rule-id",426305841).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482),new cljs.core.Keyword(null,"segment-ref","segment-ref",1989737482).cljs$core$IFn$_invoke$arity$1(rule),new cljs.core.Keyword(null,"valid","valid",155614240),valid_QMARK_,new cljs.core.Keyword(null,"rule-kind","rule-kind",-1619689839),new cljs.core.Keyword(null,"kind","kind",-717265803).cljs$core$IFn$_invoke$arity$1(rule)], null);
if((!(valid_QMARK_))){
return cljs.core.assoc.call(null,G__2166,new cljs.core.Keyword(null,"invalid-description","invalid-description",97638859),cljs.core.pr_str.call(null,result));
} else {
return G__2166;
}
})();
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [annotation,next_context], null);
});
/**
 * Pick the best matching loop-specific rules for a segment based on value fit.
 * Falls back to all rules when no loop grouping is available.
 */
org.kp.kpmc.companion_rules.choose_loop_aware_rules = (function org$kp$kpmc$companion_rules$choose_loop_aware_rules(seg_id,values,seg_rules,context,expected_loop_name){
var rule_weight = (function (rule){
var G__2167 = new cljs.core.Keyword(null,"kind","kind",-717265803).cljs$core$IFn$_invoke$arity$1(rule);
var G__2167__$1 = (((G__2167 instanceof cljs.core.Keyword))?G__2167.fqn:null);
switch (G__2167__$1) {
case "cross-ref":
return (4);

break;
case "enum":
return (3);

break;
case "external-code-list":
return (2);

break;
case "pattern-hint":
return (2);

break;
case "literal":
return (2);

break;
case "placeholder":
return (1);

break;
case "open":
return (0);

break;
default:
return (1);

}
});
var groups = cljs.core.vec.call(null,cljs.core.map.call(null,(function (p__2168){
var vec__2169 = p__2168;
var _ = cljs.core.nth.call(null,vec__2169,(0),null);
var rs = cljs.core.nth.call(null,vec__2169,(1),null);
return cljs.core.sort_by.call(null,new cljs.core.Keyword(null,"position","position",-2011731912),rs);
}),cljs.core.sort_by.call(null,cljs.core.key,cljs.core.group_by.call(null,(function (r){
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(r),new cljs.core.Keyword(null,"segment-description","segment-description",-1183758987).cljs$core$IFn$_invoke$arity$1(r)], null);
}),seg_rules))));
if((cljs.core.count.call(null,groups) <= (1))){
return cljs.core.first.call(null,groups);
} else {
var scored = cljs.core.map.call(null,(function (rules){
var result = cljs.core.reduce.call(null,(function (p__2172,rule){
var map__2173 = p__2172;
var map__2173__$1 = cljs.core.__destructure_map.call(null,map__2173);
var ctx = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"ctx","ctx",-493610118));
var anns = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"anns","anns",979004417));
var passed = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"passed","passed",-28165278));
var failed = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"failed","failed",-1397425762));
var pass_weight = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"pass-weight","pass-weight",-1841056979));
var fail_weight = cljs.core.get.call(null,map__2173__$1,new cljs.core.Keyword(null,"fail-weight","fail-weight",-794544516));
var position = new cljs.core.Keyword(null,"position","position",-2011731912).cljs$core$IFn$_invoke$arity$1(rule);
var value = cljs.core.nth.call(null,values,(position - (1)),null);
var vec__2174 = org.kp.kpmc.companion_rules.run_rule_preview.call(null,ctx,rule,seg_id,position,value);
var ann = cljs.core.nth.call(null,vec__2174,(0),null);
var next_ctx = cljs.core.nth.call(null,vec__2174,(1),null);
var w = rule_weight.call(null,rule);
return new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"ctx","ctx",-493610118),next_ctx,new cljs.core.Keyword(null,"anns","anns",979004417),cljs.core.conj.call(null,anns,ann),new cljs.core.Keyword(null,"passed","passed",-28165278),(cljs.core.truth_(new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(ann))?(passed + (1)):passed),new cljs.core.Keyword(null,"failed","failed",-1397425762),(cljs.core.truth_(new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(ann))?failed:(failed + (1))),new cljs.core.Keyword(null,"pass-weight","pass-weight",-1841056979),(cljs.core.truth_(new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(ann))?(pass_weight + w):pass_weight),new cljs.core.Keyword(null,"fail-weight","fail-weight",-794544516),(cljs.core.truth_(new cljs.core.Keyword(null,"valid","valid",155614240).cljs$core$IFn$_invoke$arity$1(ann))?fail_weight:(fail_weight + w))], null);
}),new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"ctx","ctx",-493610118),context,new cljs.core.Keyword(null,"anns","anns",979004417),cljs.core.PersistentVector.EMPTY,new cljs.core.Keyword(null,"passed","passed",-28165278),(0),new cljs.core.Keyword(null,"failed","failed",-1397425762),(0),new cljs.core.Keyword(null,"pass-weight","pass-weight",-1841056979),(0),new cljs.core.Keyword(null,"fail-weight","fail-weight",-794544516),(0)], null),rules);
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"rules","rules",1198912366),rules,new cljs.core.Keyword(null,"passed","passed",-28165278),new cljs.core.Keyword(null,"passed","passed",-28165278).cljs$core$IFn$_invoke$arity$1(result),new cljs.core.Keyword(null,"failed","failed",-1397425762),new cljs.core.Keyword(null,"failed","failed",-1397425762).cljs$core$IFn$_invoke$arity$1(result),new cljs.core.Keyword(null,"score","score",-1963588780),new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"pass-weight","pass-weight",-1841056979).cljs$core$IFn$_invoke$arity$1(result),(- new cljs.core.Keyword(null,"fail-weight","fail-weight",-794544516).cljs$core$IFn$_invoke$arity$1(result)),(cljs.core.truth_((function (){var and__5140__auto__ = expected_loop_name;
if(cljs.core.truth_(and__5140__auto__)){
return cljs.core._EQ_.call(null,expected_loop_name,new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,rules)));
} else {
return and__5140__auto__;
}
})())?(1):(0)),((cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"required","required",1807647006),new cljs.core.Keyword(null,"segment-requirement","segment-requirement",-1307113229).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,rules))))?(1):(0)),new cljs.core.Keyword(null,"passed","passed",-28165278).cljs$core$IFn$_invoke$arity$1(result),(- new cljs.core.Keyword(null,"failed","failed",-1397425762).cljs$core$IFn$_invoke$arity$1(result)),cljs.core.count.call(null,rules)], null)], null);
}),groups);
var scoped_scored = (cljs.core.truth_(expected_loop_name)?(function (){var m = cljs.core.filter.call(null,(function (p__2177){
var map__2178 = p__2177;
var map__2178__$1 = cljs.core.__destructure_map.call(null,map__2178);
var rules = cljs.core.get.call(null,map__2178__$1,new cljs.core.Keyword(null,"rules","rules",1198912366));
return cljs.core._EQ_.call(null,expected_loop_name,new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,rules)));
}),scored);
if(cljs.core.seq.call(null,m)){
return m;
} else {
return scored;
}
})():scored);
return new cljs.core.Keyword(null,"rules","rules",1198912366).cljs$core$IFn$_invoke$arity$1(cljs.core.apply.call(null,cljs.core.max_key,new cljs.core.Keyword(null,"score","score",-1963588780),scoped_scored));
}
});
/**
 * Build per-segment loop order and whether occurrence-based advancement is safe.
 * Advancement is disabled when a segment has multiple variants within a loop
 * (e.g., REF variants in loop 2000).
 */
org.kp.kpmc.companion_rules.build_loop_order_by_segment = (function org$kp$kpmc$companion_rules$build_loop_order_by_segment(rules){
var with_loop = cljs.core.filter.call(null,(function (p__2181){
var map__2182 = p__2181;
var map__2182__$1 = cljs.core.__destructure_map.call(null,map__2182);
var segment_id = cljs.core.get.call(null,map__2182__$1,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590));
var loop_name = cljs.core.get.call(null,map__2182__$1,new cljs.core.Keyword(null,"loop-name","loop-name",468086403));
return (((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,segment_id)))) && ((!(org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,loop_name)))));
}),rules);
var order_map = cljs.core.reduce.call(null,(function (acc,p__2183){
var map__2184 = p__2183;
var map__2184__$1 = cljs.core.__destructure_map.call(null,map__2184);
var segment_id = cljs.core.get.call(null,map__2184__$1,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590));
var loop_name = cljs.core.get.call(null,map__2184__$1,new cljs.core.Keyword(null,"loop-name","loop-name",468086403));
var existing = cljs.core.get.call(null,acc,segment_id,cljs.core.PersistentVector.EMPTY);
if(cljs.core.truth_(cljs.core.some.call(null,(function (p1__2180_SHARP_){
return cljs.core._EQ_.call(null,p1__2180_SHARP_,loop_name);
}),existing))){
return acc;
} else {
return cljs.core.assoc.call(null,acc,segment_id,cljs.core.conj.call(null,existing,loop_name));
}
}),cljs.core.PersistentArrayMap.EMPTY,with_loop);
var multi_variant_QMARK_ = cljs.core.reduce.call(null,(function (acc,p__2185){
var vec__2186 = p__2185;
var vec__2189 = cljs.core.nth.call(null,vec__2186,(0),null);
var segment_id = cljs.core.nth.call(null,vec__2189,(0),null);
var _ = cljs.core.nth.call(null,vec__2189,(1),null);
var rs = cljs.core.nth.call(null,vec__2186,(1),null);
var variant_count = cljs.core.count.call(null,cljs.core.distinct.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"segment-description","segment-description",-1183758987),rs)));
if((variant_count > (1))){
return cljs.core.assoc.call(null,acc,segment_id,true);
} else {
return acc;
}
}),cljs.core.PersistentArrayMap.EMPTY,cljs.core.group_by.call(null,(function (p__2192){
var map__2193 = p__2192;
var map__2193__$1 = cljs.core.__destructure_map.call(null,map__2193);
var segment_id = cljs.core.get.call(null,map__2193__$1,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590));
var loop_name = cljs.core.get.call(null,map__2193__$1,new cljs.core.Keyword(null,"loop-name","loop-name",468086403));
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [segment_id,loop_name], null);
}),with_loop));
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,(function (p__2194){
var vec__2195 = p__2194;
var segment_id = cljs.core.nth.call(null,vec__2195,(0),null);
var order = cljs.core.nth.call(null,vec__2195,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [segment_id,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"order","order",-1254677256),order,new cljs.core.Keyword(null,"advance-by-occurrence?","advance-by-occurrence?",1553353324),(!(cljs.core.get.call(null,multi_variant_QMARK_,segment_id,false) === true))], null)], null);
}),order_map));
});
/**
 * Given zero-based segment occurrence, return preferred loop name by companion order.
 */
org.kp.kpmc.companion_rules.expected_loop_for_occurrence = (function org$kp$kpmc$companion_rules$expected_loop_for_occurrence(loop_order_by_seg,seg_id,occurrence){
var map__2198 = cljs.core.get.call(null,loop_order_by_seg,seg_id);
var map__2198__$1 = cljs.core.__destructure_map.call(null,map__2198);
var order = cljs.core.get.call(null,map__2198__$1,new cljs.core.Keyword(null,"order","order",-1254677256));
var advance_by_occurrence_QMARK_ = cljs.core.get.call(null,map__2198__$1,new cljs.core.Keyword(null,"advance-by-occurrence?","advance-by-occurrence?",1553353324));
if(cljs.core.seq.call(null,order)){
if(cljs.core.truth_(advance_by_occurrence_QMARK_)){
return cljs.core.nth.call(null,order,cljs.core.min.call(null,occurrence,(cljs.core.count.call(null,order) - (1))),null);
} else {
return cljs.core.first.call(null,order);
}
} else {
return null;
}
});
/**
 * Validate parsed EDI tree using compiled rules and annotate data units with :valid.
 * Works with keyword-tag or string-tag parse trees.
 */
org.kp.kpmc.companion_rules.validate_edi_parse_tree = (function org$kp$kpmc$companion_rules$validate_edi_parse_tree(var_args){
var G__2200 = arguments.length;
switch (G__2200) {
case 2:
return org.kp.kpmc.companion_rules.validate_edi_parse_tree.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return org.kp.kpmc.companion_rules.validate_edi_parse_tree.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",arguments.length].join("")));

}
});

(org.kp.kpmc.companion_rules.validate_edi_parse_tree.cljs$core$IFn$_invoke$arity$2 = (function (parse_tree,rules){
return org.kp.kpmc.companion_rules.validate_edi_parse_tree.call(null,parse_tree,rules,cljs.core.PersistentArrayMap.EMPTY);
}));

(org.kp.kpmc.companion_rules.validate_edi_parse_tree.cljs$core$IFn$_invoke$arity$3 = (function (parse_tree,rules,opts){
var rules_by_seg = cljs.core.group_by.call(null,new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),rules);
var loop_order_by_seg = org.kp.kpmc.companion_rules.build_loop_order_by_segment.call(null,rules);
var seg_occurrence_STAR_ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var context_STAR_ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var db_state_STAR_ = cljs.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"commercial-refs","commercial-refs",508899454),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"subscribers","subscribers",-606401562),cljs.core.PersistentVector.EMPTY,new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038),null], null));
var stats_STAR_ = cljs.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"total","total",1916810418),(0),new cljs.core.Keyword(null,"passed","passed",-28165278),(0),new cljs.core.Keyword(null,"failed","failed",-1397425762),(0),new cljs.core.Keyword(null,"by-rule","by-rule",1219942905),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"lookup","lookup",1225356838),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"attempted","attempted",1101657210),(0),new cljs.core.Keyword(null,"passed","passed",-28165278),(0),new cljs.core.Keyword(null,"failed","failed",-1397425762),(0),new cljs.core.Keyword(null,"skipped","skipped",-1144887090),(0)], null)], null));
var lookup_state = new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"lookup-index","lookup-index",-1886927582),new cljs.core.Keyword(null,"lookup-index","lookup-index",-1886927582).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"lookup-executor","lookup-executor",-158156549),new cljs.core.Keyword(null,"lookup-executor","lookup-executor",-158156549).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460),new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460).cljs$core$IFn$_invoke$arity$1(opts) === true], null);
var enrich = (function org$kp$kpmc$companion_rules$enrich(node){
if((!(cljs.core.sequential_QMARK_.call(null,node)))){
return node;
} else {
if(org.kp.kpmc.companion_rules.tag_EQ_.call(null,node,"data_segment")){
var seg_id = org.kp.kpmc.companion_rules.extract_seg_id.call(null,node);
var values = org.kp.kpmc.companion_rules.extract_unit_values.call(null,node);
var occurrence = cljs.core.get.call(null,cljs.core.deref.call(null,seg_occurrence_STAR_),seg_id,(0));
var _ = cljs.core.swap_BANG_.call(null,seg_occurrence_STAR_,cljs.core.update,seg_id,cljs.core.fnil.call(null,cljs.core.inc,(0)));
var expected_loop = org.kp.kpmc.companion_rules.expected_loop_for_occurrence.call(null,loop_order_by_seg,seg_id,occurrence);
var seg_rules = cljs.core.sort_by.call(null,new cljs.core.Keyword(null,"position","position",-2011731912),cljs.core.get.call(null,rules_by_seg,seg_id,cljs.core.PersistentVector.EMPTY));
var active_rules = org.kp.kpmc.companion_rules.choose_loop_aware_rules.call(null,seg_id,values,seg_rules,cljs.core.deref.call(null,context_STAR_),expected_loop);
var children = cljs.core.vec.call(null,cljs.core.rest.call(null,node));
var unit_idxs = cljs.core.vec.call(null,cljs.core.map.call(null,cljs.core.first,cljs.core.filter.call(null,(function (p__2201){
var vec__2202 = p__2201;
var ___$1 = cljs.core.nth.call(null,vec__2202,(0),null);
var c = cljs.core.nth.call(null,vec__2202,(1),null);
return org.kp.kpmc.companion_rules.tag_EQ_.call(null,c,"data_segment_unit");
}),cljs.core.map_indexed.call(null,cljs.core.vector,children))));
var pos__GT_rule = cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,cljs.core.juxt.call(null,new cljs.core.Keyword(null,"position","position",-2011731912),cljs.core.identity),active_rules));
var new_children = cljs.core.reduce.call(null,(function (acc,p__2205){
var vec__2206 = p__2205;
var pos = cljs.core.nth.call(null,vec__2206,(0),null);
var unit_index = cljs.core.nth.call(null,vec__2206,(1),null);
var position = (pos + (1));
var unit = cljs.core.nth.call(null,acc,unit_index);
var value = cljs.core.nth.call(null,values,pos,null);
var ref = org.kp.kpmc.companion_rules.to_ref.call(null,seg_id,position);
var ___$1 = ((org.kp.kpmc.companion_rules.blankish_QMARK_.call(null,value))?null:cljs.core.swap_BANG_.call(null,context_STAR_,cljs.core.assoc,ref,value));
var rule = cljs.core.get.call(null,pos__GT_rule,position);
if((rule == null)){
return acc;
} else {
var annotation = org.kp.kpmc.companion_rules.run_rule_on_value.call(null,context_STAR_,stats_STAR_,db_state_STAR_,rule,seg_id,position,value,lookup_state);
return cljs.core.assoc.call(null,acc,unit_index,org.kp.kpmc.companion_rules.annotate_unit.call(null,unit,annotation));
}
}),children,cljs.core.map_indexed.call(null,cljs.core.vector,unit_idxs));
return cljs.core.into.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,node)], null),cljs.core.map.call(null,org$kp$kpmc$companion_rules$enrich,new_children));
} else {
if(org.kp.kpmc.companion_rules.tag_EQ_.call(null,node,"raw_segment")){
var raw_text = cljs.core.second.call(null,node);
var vec__2209 = org.kp.kpmc.companion_rules.split_raw_segment.call(null,raw_text);
var seg_id = cljs.core.nth.call(null,vec__2209,(0),null);
var values = cljs.core.nth.call(null,vec__2209,(1),null);
var occurrence = cljs.core.get.call(null,cljs.core.deref.call(null,seg_occurrence_STAR_),seg_id,(0));
var _ = cljs.core.swap_BANG_.call(null,seg_occurrence_STAR_,cljs.core.update,seg_id,cljs.core.fnil.call(null,cljs.core.inc,(0)));
var expected_loop = org.kp.kpmc.companion_rules.expected_loop_for_occurrence.call(null,loop_order_by_seg,seg_id,occurrence);
var seg_rules = cljs.core.sort_by.call(null,new cljs.core.Keyword(null,"position","position",-2011731912),cljs.core.get.call(null,rules_by_seg,seg_id,cljs.core.PersistentVector.EMPTY));
var active_rules = org.kp.kpmc.companion_rules.choose_loop_aware_rules.call(null,seg_id,values,seg_rules,cljs.core.deref.call(null,context_STAR_),expected_loop);
var annotations = cljs.core.vec.call(null,cljs.core.map.call(null,(function (rule){
var position = new cljs.core.Keyword(null,"position","position",-2011731912).cljs$core$IFn$_invoke$arity$1(rule);
var value = cljs.core.nth.call(null,values,(position - (1)),null);
return org.kp.kpmc.companion_rules.run_rule_on_value.call(null,context_STAR_,stats_STAR_,db_state_STAR_,rule,seg_id,position,value,lookup_state);
}),active_rules));
var segment_valid_QMARK_ = cljs.core.every_QMARK_.call(null,new cljs.core.Keyword(null,"valid","valid",155614240),annotations);
if(cljs.core.seq.call(null,annotations)){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,node),new cljs.core.PersistentArrayMap(null, 8, [new cljs.core.Keyword(null,"segment-id","segment-id",1810133590),seg_id,new cljs.core.Keyword(null,"expected-loop","expected-loop",145159168),expected_loop,new cljs.core.Keyword(null,"loop-name","loop-name",468086403),new cljs.core.Keyword(null,"loop-name","loop-name",468086403).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,active_rules)),new cljs.core.Keyword(null,"loop-description","loop-description",120734501),new cljs.core.Keyword(null,"segment-description","segment-description",-1183758987).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,active_rules)),new cljs.core.Keyword(null,"segment-requirement","segment-requirement",-1307113229),new cljs.core.Keyword(null,"segment-requirement","segment-requirement",-1307113229).cljs$core$IFn$_invoke$arity$1(cljs.core.first.call(null,active_rules)),new cljs.core.Keyword(null,"validated-count","validated-count",1468561061),cljs.core.count.call(null,annotations),new cljs.core.Keyword(null,"valid","valid",155614240),segment_valid_QMARK_,new cljs.core.Keyword(null,"element-validations","element-validations",1400120989),annotations], null),raw_text], null);
} else {
return node;
}
} else {
return cljs.core.into.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.first.call(null,node)], null),cljs.core.map.call(null,org$kp$kpmc$companion_rules$enrich,cljs.core.rest.call(null,node)));

}
}
}
});
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"annotated-tree","annotated-tree",262346771),enrich.call(null,parse_tree),new cljs.core.Keyword(null,"stats","stats",-85643011),cljs.core.deref.call(null,stats_STAR_),new cljs.core.Keyword(null,"context","context",-830191113),cljs.core.deref.call(null,context_STAR_),new cljs.core.Keyword(null,"db-state","db-state",1624009049),cljs.core.deref.call(null,db_state_STAR_)], null);
}));

(org.kp.kpmc.companion_rules.validate_edi_parse_tree.cljs$lang$maxFixedArity = 3);

/**
 * Validate parsed EDI JSON text (array-based parse tree with string tags).
 * Returns cljs map including annotated tree and summary stats.
 */
org.kp.kpmc.companion_rules.validate_parsed_json_text = (function org$kp$kpmc$companion_rules$validate_parsed_json_text(parsed_json_text,rules){
var parsed = JSON.parse(parsed_json_text);
var parse_tree = cljs.core.js__GT_clj.call(null,parsed);
return org.kp.kpmc.companion_rules.validate_edi_parse_tree.call(null,parse_tree,rules);
});
/**
 * Test harness: parse companion CSV -> compile rules -> parse an EDI file -> validate.
 *   Returns parsed tree, annotated tree, and summary focused on validation coverage.
 */
org.kp.kpmc.companion_rules.run_rule_harness = (function org$kp$kpmc$companion_rules$run_rule_harness(var_args){
var G__2214 = arguments.length;
switch (G__2214) {
case 2:
return org.kp.kpmc.companion_rules.run_rule_harness.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return org.kp.kpmc.companion_rules.run_rule_harness.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error(["Invalid arity: ",arguments.length].join("")));

}
});

(org.kp.kpmc.companion_rules.run_rule_harness.cljs$core$IFn$_invoke$arity$2 = (function (companion_csv,edi_file){
return org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file,cljs.core.PersistentArrayMap.EMPTY);
}));

(org.kp.kpmc.companion_rules.run_rule_harness.cljs$core$IFn$_invoke$arity$3 = (function (companion_csv,edi_file,opts){
cljs.core.println.call(null,"[run-rule-harness]");

var map__2215 = org.kp.kpmc.companion_rules.parse_companion_csv__GT_rules.call(null,companion_csv);
var map__2215__$1 = cljs.core.__destructure_map.call(null,map__2215);
var rules = cljs.core.get.call(null,map__2215__$1,new cljs.core.Keyword(null,"rules","rules",1198912366));
var model = cljs.core.get.call(null,map__2215__$1,new cljs.core.Keyword(null,"model","model",331153215));
var lookup_spec_file = (function (){var or__5142__auto__ = new cljs.core.Keyword(null,"lookup-spec-file","lookup-spec-file",687065480).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "save/companion-db-lookups.edn";
}
})();
var lookup_doc = org.kp.kpmc.companion_rules.load_lookup_specs.call(null,lookup_spec_file);
var lookup_index = org.kp.kpmc.companion_rules.build_lookup_index.call(null,lookup_doc);
var db_enabled_QMARK_ = ((new cljs.core.Keyword(null,"db-validation?","db-validation?",2032147196).cljs$core$IFn$_invoke$arity$1(opts) === true) || (((cljs.core._EQ_.call(null,"true",clojure.string.lower_case.call(null,(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto____$1 = org.kp.kpmc.companion_rules.env_get.call(null,"DB_VALIDATION");
if(cljs.core.truth_(or__5142__auto____$1)){
return or__5142__auto____$1;
} else {
return "";
}
})()))))) || (cljs.core._EQ_.call(null,"1",(""+cljs.core.str.cljs$core$IFn$_invoke$arity$1((function (){var or__5142__auto____$2 = org.kp.kpmc.companion_rules.env_get.call(null,"DB_VALIDATION");
if(cljs.core.truth_(or__5142__auto____$2)){
return or__5142__auto____$2;
} else {
return "";
}
})())))))));
var effective_lookup_executor = (function (){var or__5142__auto__ = new cljs.core.Keyword(null,"lookup-executor","lookup-executor",-158156549).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
if(db_enabled_QMARK_){
return org.kp.kpmc.companion_rules.make_oracle_lookup_executor.call(null,opts);
} else {
return null;
}
}
})();
var db_config = ((db_enabled_QMARK_)?org.kp.kpmc.companion_rules.resolve_db_config.call(null,opts):null);
var parse_tree = org.kp.kpmc.parser.parse_x12_full.call(null,edi_file,cljs.core.select_keys.call(null,opts,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"log-memory?","log-memory?",-916293409)], null)));
var map__2216 = org.kp.kpmc.companion_rules.validate_edi_parse_tree.call(null,parse_tree,rules,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"lookup-index","lookup-index",-1886927582),lookup_index,new cljs.core.Keyword(null,"lookup-executor","lookup-executor",-158156549),effective_lookup_executor,new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460),new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460).cljs$core$IFn$_invoke$arity$1(opts)], null));
var map__2216__$1 = cljs.core.__destructure_map.call(null,map__2216);
var annotated_tree = cljs.core.get.call(null,map__2216__$1,new cljs.core.Keyword(null,"annotated-tree","annotated-tree",262346771));
var stats = cljs.core.get.call(null,map__2216__$1,new cljs.core.Keyword(null,"stats","stats",-85643011));
var context = cljs.core.get.call(null,map__2216__$1,new cljs.core.Keyword(null,"context","context",-830191113));
var db_state = cljs.core.get.call(null,map__2216__$1,new cljs.core.Keyword(null,"db-state","db-state",1624009049));
var report = cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"lookup-summary","lookup-summary",1485614183),new cljs.core.Keyword(null,"db-validation-enabled","db-validation-enabled",-362301625),new cljs.core.Keyword(null,"lookup-spec-file","lookup-spec-file",687065480),new cljs.core.Keyword(null,"legend-count","legend-count",-564620371),new cljs.core.Keyword(null,"loop-count","loop-count",792041806),new cljs.core.Keyword(null,"subscriber-count","subscriber-count",-1251628941),new cljs.core.Keyword(null,"lookup-spec-count","lookup-spec-count",-1820151341),new cljs.core.Keyword(null,"db-env-name","db-env-name",-1250740875),new cljs.core.Keyword(null,"rule-count","rule-count",-1633498761),new cljs.core.Keyword(null,"context-keys","context-keys",-844838600),new cljs.core.Keyword(null,"element-row-count","element-row-count",1398185528),new cljs.core.Keyword(null,"rule-kind-counts","rule-kind-counts",1300665),new cljs.core.Keyword(null,"validation","validation",-2141396518)],[new cljs.core.Keyword(null,"lookup","lookup",1225356838).cljs$core$IFn$_invoke$arity$1(stats),db_enabled_QMARK_,lookup_spec_file,cljs.core.count.call(null,new cljs.core.Keyword(null,"legend","legend",-1027192245).cljs$core$IFn$_invoke$arity$1(model)),cljs.core.count.call(null,new cljs.core.Keyword(null,"loops","loops",-1766681555).cljs$core$IFn$_invoke$arity$1(model)),cljs.core.count.call(null,cljs.core.concat.call(null,new cljs.core.Keyword(null,"subscribers","subscribers",-606401562).cljs$core$IFn$_invoke$arity$1(db_state),(function (){var temp__5825__auto__ = new cljs.core.Keyword(null,"current-subscriber","current-subscriber",-1261955038).cljs$core$IFn$_invoke$arity$1(db_state);
if(cljs.core.truth_(temp__5825__auto__)){
var cur = temp__5825__auto__;
return new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cur], null);
} else {
return null;
}
})())),cljs.core.count.call(null,new cljs.core.Keyword(null,"specs","specs",1426570741).cljs$core$IFn$_invoke$arity$1(lookup_doc)),new cljs.core.Keyword(null,"env-name","env-name",1998966009).cljs$core$IFn$_invoke$arity$1(db_config),cljs.core.count.call(null,rules),cljs.core.count.call(null,context),cljs.core.count.call(null,new cljs.core.Keyword(null,"elements","elements",657646735).cljs$core$IFn$_invoke$arity$1(model)),cljs.core.frequencies.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"kind","kind",-717265803),rules)),stats]);
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"report","report",1394055010),report,new cljs.core.Keyword(null,"rules","rules",1198912366),rules,new cljs.core.Keyword(null,"parsed-tree","parsed-tree",1040023394),parse_tree,new cljs.core.Keyword(null,"annotated-tree","annotated-tree",262346771),annotated_tree], null);
}));

(org.kp.kpmc.companion_rules.run_rule_harness.cljs$lang$maxFixedArity = 3);

/**
 * Convenience harness for local baseline checks using test1.txt.
 */
org.kp.kpmc.companion_rules.run_rule_harness_on_test1 = (function org$kp$kpmc$companion_rules$run_rule_harness_on_test1(){
return org.kp.kpmc.companion_rules.run_rule_harness.call(null,"src/main/resources/TrentonSystemsInc_GA_CompanionDoc_5010a1-2025-12-29.csv","src/main/resources/edisamples/test1.txt");
});
org.kp.kpmc.companion_rules.ensure_parent_dir_BANG_ = (function org$kp$kpmc$companion_rules$ensure_parent_dir_BANG_(output_file){
var path_mod = require("path");
var fs = require("fs");
var dir = path_mod.dirname(output_file);
return fs.mkdirSync(dir,cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"recursive","recursive",718885872),true], null)));
});
/**
 * Run harness and write pretty EDN output to file.
 * Returns {:output-file ... :result ...}.
 */
org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_ = (function org$kp$kpmc$companion_rules$write_rule_harness_edn_BANG_(var_args){
var G__2219 = arguments.length;
switch (G__2219) {
case 3:
return org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",arguments.length].join("")));

}
});

(org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (companion_csv,edi_file,output_file){
cljs.core.println.call(null,"[write-rule-harness-edn!]");

var result = org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file);
var edn_text = org.kp.kpmc.io_node.to_edn_text.call(null,result);
org.kp.kpmc.companion_rules.ensure_parent_dir_BANG_.call(null,output_file);

org.kp.kpmc.io_node.write_text.call(null,output_file,edn_text);

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"output-file","output-file",-907928512),output_file,new cljs.core.Keyword(null,"result","result",1415092211),result], null);
}));

(org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (companion_csv,edi_file,output_file,opts){
var result = org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file,opts);
var edn_text = org.kp.kpmc.io_node.to_edn_text.call(null,result);
org.kp.kpmc.companion_rules.ensure_parent_dir_BANG_.call(null,output_file);

org.kp.kpmc.io_node.write_text.call(null,output_file,edn_text);

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"output-file","output-file",-907928512),output_file,new cljs.core.Keyword(null,"result","result",1415092211),result], null);
}));

(org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.cljs$lang$maxFixedArity = 4);

/**
 * Run harness and write pretty JSON output to file.
 * Returns {:output-file ... :result ...}.
 */
org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_ = (function org$kp$kpmc$companion_rules$write_rule_harness_json_BANG_(var_args){
var G__2222 = arguments.length;
switch (G__2222) {
case 3:
return org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error(["Invalid arity: ",arguments.length].join("")));

}
});

(org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (companion_csv,edi_file,output_file){
var result = org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file);
var json_text = JSON.stringify(cljs.core.clj__GT_js.call(null,result),null,(2));
org.kp.kpmc.companion_rules.ensure_parent_dir_BANG_.call(null,output_file);

org.kp.kpmc.io_node.write_text.call(null,output_file,json_text);

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"output-file","output-file",-907928512),output_file,new cljs.core.Keyword(null,"result","result",1415092211),result], null);
}));

(org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (companion_csv,edi_file,output_file,opts){
var result = org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file,opts);
var json_text = JSON.stringify(cljs.core.clj__GT_js.call(null,result),null,(2));
org.kp.kpmc.companion_rules.ensure_parent_dir_BANG_.call(null,output_file);

org.kp.kpmc.io_node.write_text.call(null,output_file,json_text);

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"output-file","output-file",-907928512),output_file,new cljs.core.Keyword(null,"result","result",1415092211),result], null);
}));

(org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.cljs$lang$maxFixedArity = 4);

org.kp.kpmc.companion_rules.default_json_output_file = (function org$kp$kpmc$companion_rules$default_json_output_file(edn_output_file){
if(clojure.string.ends_with_QMARK_.call(null,(function (){var or__5142__auto__ = edn_output_file;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return "";
}
})(),".edn")){
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(cljs.core.subs.call(null,edn_output_file,(0),(cljs.core.count.call(null,edn_output_file) - (4))))+".json");
} else {
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(edn_output_file)+".json");
}
});
/**
 * Run run-rule-harness-on-test1 and write pretty EDN output for detailed review.
 *   Also writes JSON output alongside EDN.
 *   Default outputs: save/rule-harness-test1.edn and save/rule-harness-test1.json
 */
org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_ = (function org$kp$kpmc$companion_rules$write_rule_harness_on_test1_edn_BANG_(var_args){
var G__2225 = arguments.length;
switch (G__2225) {
case 0:
return org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error(["Invalid arity: ",arguments.length].join("")));

}
});

(org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.cljs$core$IFn$_invoke$arity$0 = (function (){
cljs.core.println.call(null,"just checking.....");

return org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.call(null,"save/rule-harness-test1.edn");
}));

(org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.cljs$core$IFn$_invoke$arity$1 = (function (output_file){
var companion_csv = "src/main/resources/TrentonSystemsInc_GA_CompanionDoc_5010a1-2025-12-29.csv";
var edi_file = "src/main/resources/edisamples/test1.txt";
var json_output_file = org.kp.kpmc.companion_rules.default_json_output_file.call(null,output_file);
var edn_resp = org.kp.kpmc.companion_rules.write_rule_harness_edn_BANG_.call(null,companion_csv,edi_file,output_file);
var json_resp = org.kp.kpmc.companion_rules.write_rule_harness_json_BANG_.call(null,companion_csv,edi_file,json_output_file);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"edn-output-file","edn-output-file",84595148),new cljs.core.Keyword(null,"output-file","output-file",-907928512).cljs$core$IFn$_invoke$arity$1(edn_resp),new cljs.core.Keyword(null,"json-output-file","json-output-file",1959735214),new cljs.core.Keyword(null,"output-file","output-file",-907928512).cljs$core$IFn$_invoke$arity$1(json_resp),new cljs.core.Keyword(null,"result","result",1415092211),new cljs.core.Keyword(null,"result","result",1415092211).cljs$core$IFn$_invoke$arity$1(edn_resp)], null);
}));

(org.kp.kpmc.companion_rules.write_rule_harness_on_test1_edn_BANG_.cljs$lang$maxFixedArity = 1);


//# sourceMappingURL=companion_rules.js.map
