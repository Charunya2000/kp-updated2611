// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('org.kp.kpmc.io_node');
goog.require('cljs.core');
goog.require('cljs.pprint');
/**
 * Read UTF-8 text from disk via Node.js fs.
 */
org.kp.kpmc.io_node.read_text = (function org$kp$kpmc$io_node$read_text(path){
return require("fs").readFileSync(path,"utf8");
});
/**
 * Write UTF-8 text to disk via Node.js fs.
 */
org.kp.kpmc.io_node.write_text = (function org$kp$kpmc$io_node$write_text(path,text){
return require("fs").writeFileSync(path,text,"utf8");
});
/**
 * Render data as pretty EDN text.
 */
org.kp.kpmc.io_node.to_edn_text = (function org$kp$kpmc$io_node$to_edn_text(data){
var sb__5795__auto__ = (new goog.string.StringBuffer());
var _STAR_print_newline_STAR__orig_val__624_628 = cljs.core._STAR_print_newline_STAR_;
var _STAR_print_fn_STAR__orig_val__625_629 = cljs.core._STAR_print_fn_STAR_;
var _STAR_print_newline_STAR__temp_val__626_630 = true;
var _STAR_print_fn_STAR__temp_val__627_631 = (function (x__5796__auto__){
return sb__5795__auto__.append(x__5796__auto__);
});
(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__temp_val__626_630);

(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__temp_val__627_631);

try{cljs.pprint.pprint.call(null,data);
}finally {(cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR__orig_val__625_629);

(cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR__orig_val__624_628);
}
return (""+cljs.core.str.cljs$core$IFn$_invoke$arity$1(sb__5795__auto__));
});

//# sourceMappingURL=io_node.js.map
