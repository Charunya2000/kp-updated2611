(ns org.kp.kpmc.io-node
  (:require [cljs.pprint :as pprint]))

(defn read-text
  "Read UTF-8 text from disk via Node.js fs."
  [path]
  (.readFileSync (js/require "fs") path "utf8"))

(defn write-text
  "Write UTF-8 text to disk via Node.js fs."
  [path text]
  (.writeFileSync (js/require "fs") path text "utf8"))

(defn to-edn-text
  "Render data as pretty EDN text."
  [data]
  (with-out-str (pprint/pprint data)))