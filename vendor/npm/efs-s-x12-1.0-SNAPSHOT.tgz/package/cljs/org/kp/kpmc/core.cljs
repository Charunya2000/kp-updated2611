(ns org.kp.kpmc.core
  (:require [org.kp.kpmc.io-node :as io]
            [org.kp.kpmc.parser :as parser]
            [org.kp.kpmc.companion :as companion]
            [org.kp.kpmc.enrich :as enrich]
            [org.kp.kpmc.companion-rules :as companion-rules]
            [org.kp.kpmc.cli :as cli]))

;; IO
(def read-text io/read-text)
(def write-text io/write-text)
(def to-edn-text io/to-edn-text)

;; Parser
(def reverso parser/reverso)
(def extract-text-by-span parser/extract-text-by-span)
(def find-in-parse-tree parser/find-in-parse-tree)
(def find-all-nodes parser/find-all-nodes)
(def create-parsers parser/create-parsers)
(def testX12 parser/testX12)
(def testX12-stage1 parser/testX12-stage1)
(def testX12-stage2 parser/testX12-stage2)
(def testX12-stage3 parser/testX12-stage3)
(def testX12-hierarchical parser/testX12-hierarchical)
(def parse-envelope parser/parse-envelope)
(def extract-function-bodies parser/extract-function-bodies)
(def parse-function-body parser/parse-function-body)
(def extract-transaction-sets parser/extract-transaction-sets)
(def parse-trans-body parser/parse-trans-body)
(def parse-x12-chunked parser/parse-x12-chunked)
(def test-chunked-parse parser/test-chunked-parse)
(def parse-x12-full parser/parse-x12-full)
(def test-full-parse parser/test-full-parse)

;; JSON-friendly parser wrappers for Node.js consumers.
(defn parse-x12-chunked-json
  [filepath]
  (clj->js (parser/parse-x12-chunked filepath)))

(defn parse-x12-full-json
  [filepath]
  (clj->js (parser/parse-x12-full filepath)))

;; Companion guide parsing
(def join-multiline-quoted-fields companion/join-multiline-quoted-fields)
(def parse-csv-line companion/parse-csv-line)
(def parse-loop-header companion/parse-loop-header)
(def parse-companion-guide-text companion/parse-companion-guide-text)
(def parse-companion-guide companion/parse-companion-guide)
(def save-companion-guide-edn companion/save-companion-guide-edn)
(def parse-segment-ref companion/parse-segment-ref)

(defn parse-companion-guide-json
  [csv-file]
  (clj->js (companion/parse-companion-guide csv-file)))

;; Enrichment and validation
(def build-companion-index enrich/build-companion-index)
(def find-loop-def enrich/find-loop-def)
(def annotate-children enrich/annotate-children)
(def parse-kp-allowed-values enrich/parse-kp-allowed-values)
(def validate-kp-format enrich/validate-kp-format)
(def validate-element enrich/validate-element)
(def annotate-and-validate-children enrich/annotate-and-validate-children)
(def enrich-parse-tree enrich/enrich-parse-tree)
(def enrich-x12-with-companion-guide enrich/enrich-x12-with-companion-guide)

(defn enrich-parse-tree-json
  [parse-tree-json companion-guide-json]
  (let [keywordize-node-tags
        (fn keywordize-node-tags [node]
          (cond
            (vector? node)
            (let [head (first node)
                  normalized-head (if (string? head) (keyword head) head)]
              (into [normalized-head]
                    (map keywordize-node-tags (rest node))))

            (map? node)
            (into {} (map (fn [[k v]] [k (keywordize-node-tags v)]) node))

            (sequential? node)
            (mapv keywordize-node-tags node)

            :else node))
        parse-tree (-> parse-tree-json
                       (js->clj :keywordize-keys true)
                       keywordize-node-tags)
        companion-guide (js->clj companion-guide-json :keywordize-keys true)]
    (clj->js (enrich/enrich-parse-tree parse-tree companion-guide))))

;; Companion rule harness / validation
(def run-rule-harness companion-rules/run-rule-harness)

(defn- normalize-rule-harness-opts
  [opts]
  (let [o (or opts {})]
    (cond-> o
      (contains? o :lookupSpecFile)
      (assoc :lookup-spec-file (:lookupSpecFile o))

      (contains? o :includeLookupSql)
      (assoc :include-lookup-sql? (:includeLookupSql o))

      (contains? o :includeLookupSql?)
      (assoc :include-lookup-sql? (:includeLookupSql? o))

      (contains? o :dbValidation)
      (assoc :db-validation? (:dbValidation o))

      (contains? o :dbValidation?)
      (assoc :db-validation? (:dbValidation? o))

      (contains? o :envName)
      (assoc :env-name (:envName o))

      (contains? o :subscriberOnlyDbValidation)
      (assoc :subscriber-only-db-validation? (:subscriberOnlyDbValidation o))

      (contains? o :logMemory)
      (assoc :log-memory? (:logMemory o)))))

(defn run-rule-harness-json
  [companion-csv edi-file opts-json]
  (let [opts (normalize-rule-harness-opts
              (if (some? opts-json)
                (js->clj opts-json :keywordize-keys true)
                {}))]
    (clj->js (companion-rules/run-rule-harness companion-csv edi-file opts))))

(defn parse-enrich-validate-json
  "One-step API for Node consumers.
   Returns parsed tree, enriched tree, and validation summary JSON-friendly payload."
  [companion-csv edi-file opts-json]
  (let [opts (normalize-rule-harness-opts
              (if (some? opts-json)
                (js->clj opts-json :keywordize-keys true)
                {}))
        harness (companion-rules/run-rule-harness companion-csv edi-file opts)
        report (:report harness)]
    (clj->js {:parsed (:parsed-tree harness)
              :enriched (:annotated-tree harness)
              :validation-summary {:total (get-in report [:validation :total])
                                   :passed (get-in report [:validation :passed])
                                   :failed (get-in report [:validation :failed])
                                   :lookup (:lookup-summary report)}
              :report report})))

;; CLI
(def parse-cli-opts cli/parse-cli-opts)
(def cli-usage cli/cli-usage)
(def require-opt cli/require-opt)
(def run-cli! cli/run-cli!)

(defn -main
  [& args]
  (apply cli/-main args))