// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('org.kp.kpmc.core');
goog.require('cljs.core');
goog.require('org.kp.kpmc.io_node');
goog.require('org.kp.kpmc.parser');
goog.require('org.kp.kpmc.companion');
goog.require('org.kp.kpmc.enrich');
goog.require('org.kp.kpmc.companion_rules');
goog.require('org.kp.kpmc.cli');
org.kp.kpmc.core.read_text = org.kp.kpmc.io_node.read_text;
org.kp.kpmc.core.write_text = org.kp.kpmc.io_node.write_text;
org.kp.kpmc.core.to_edn_text = org.kp.kpmc.io_node.to_edn_text;
org.kp.kpmc.core.reverso = org.kp.kpmc.parser.reverso;
org.kp.kpmc.core.extract_text_by_span = org.kp.kpmc.parser.extract_text_by_span;
org.kp.kpmc.core.find_in_parse_tree = org.kp.kpmc.parser.find_in_parse_tree;
org.kp.kpmc.core.find_all_nodes = org.kp.kpmc.parser.find_all_nodes;
org.kp.kpmc.core.create_parsers = org.kp.kpmc.parser.create_parsers;
org.kp.kpmc.core.testX12 = org.kp.kpmc.parser.testX12;
org.kp.kpmc.core.testX12_stage1 = org.kp.kpmc.parser.testX12_stage1;
org.kp.kpmc.core.testX12_stage2 = org.kp.kpmc.parser.testX12_stage2;
org.kp.kpmc.core.testX12_stage3 = org.kp.kpmc.parser.testX12_stage3;
org.kp.kpmc.core.testX12_hierarchical = org.kp.kpmc.parser.testX12_hierarchical;
org.kp.kpmc.core.parse_envelope = org.kp.kpmc.parser.parse_envelope;
org.kp.kpmc.core.extract_function_bodies = org.kp.kpmc.parser.extract_function_bodies;
org.kp.kpmc.core.parse_function_body = org.kp.kpmc.parser.parse_function_body;
org.kp.kpmc.core.extract_transaction_sets = org.kp.kpmc.parser.extract_transaction_sets;
org.kp.kpmc.core.parse_trans_body = org.kp.kpmc.parser.parse_trans_body;
org.kp.kpmc.core.parse_x12_chunked = org.kp.kpmc.parser.parse_x12_chunked;
org.kp.kpmc.core.test_chunked_parse = org.kp.kpmc.parser.test_chunked_parse;
org.kp.kpmc.core.parse_x12_full = org.kp.kpmc.parser.parse_x12_full;
org.kp.kpmc.core.test_full_parse = org.kp.kpmc.parser.test_full_parse;
org.kp.kpmc.core.parse_x12_chunked_json = (function org$kp$kpmc$core$parse_x12_chunked_json(filepath){
return cljs.core.clj__GT_js.call(null,org.kp.kpmc.parser.parse_x12_chunked.call(null,filepath));
});
org.kp.kpmc.core.parse_x12_full_json = (function org$kp$kpmc$core$parse_x12_full_json(filepath){
return cljs.core.clj__GT_js.call(null,org.kp.kpmc.parser.parse_x12_full.call(null,filepath));
});
org.kp.kpmc.core.join_multiline_quoted_fields = org.kp.kpmc.companion.join_multiline_quoted_fields;
org.kp.kpmc.core.parse_csv_line = org.kp.kpmc.companion.parse_csv_line;
org.kp.kpmc.core.parse_loop_header = org.kp.kpmc.companion.parse_loop_header;
org.kp.kpmc.core.parse_companion_guide_text = org.kp.kpmc.companion.parse_companion_guide_text;
org.kp.kpmc.core.parse_companion_guide = org.kp.kpmc.companion.parse_companion_guide;
org.kp.kpmc.core.save_companion_guide_edn = org.kp.kpmc.companion.save_companion_guide_edn;
org.kp.kpmc.core.parse_segment_ref = org.kp.kpmc.companion.parse_segment_ref;
org.kp.kpmc.core.parse_companion_guide_json = (function org$kp$kpmc$core$parse_companion_guide_json(csv_file){
return cljs.core.clj__GT_js.call(null,org.kp.kpmc.companion.parse_companion_guide.call(null,csv_file));
});
org.kp.kpmc.core.build_companion_index = org.kp.kpmc.enrich.build_companion_index;
org.kp.kpmc.core.find_loop_def = org.kp.kpmc.enrich.find_loop_def;
org.kp.kpmc.core.annotate_children = org.kp.kpmc.enrich.annotate_children;
org.kp.kpmc.core.parse_kp_allowed_values = org.kp.kpmc.enrich.parse_kp_allowed_values;
org.kp.kpmc.core.validate_kp_format = org.kp.kpmc.enrich.validate_kp_format;
org.kp.kpmc.core.validate_element = org.kp.kpmc.enrich.validate_element;
org.kp.kpmc.core.annotate_and_validate_children = org.kp.kpmc.enrich.annotate_and_validate_children;
org.kp.kpmc.core.enrich_parse_tree = org.kp.kpmc.enrich.enrich_parse_tree;
org.kp.kpmc.core.enrich_x12_with_companion_guide = org.kp.kpmc.enrich.enrich_x12_with_companion_guide;
org.kp.kpmc.core.enrich_parse_tree_json = (function org$kp$kpmc$core$enrich_parse_tree_json(parse_tree_json,companion_guide_json){
var keywordize_node_tags = (function org$kp$kpmc$core$enrich_parse_tree_json_$_keywordize_node_tags(node){
if(cljs.core.vector_QMARK_.call(null,node)){
var head = cljs.core.first.call(null,node);
var normalized_head = ((typeof head === 'string')?cljs.core.keyword.call(null,head):head);
return cljs.core.into.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [normalized_head], null),cljs.core.map.call(null,org$kp$kpmc$core$enrich_parse_tree_json_$_keywordize_node_tags,cljs.core.rest.call(null,node)));
} else {
if(cljs.core.map_QMARK_.call(null,node)){
return cljs.core.into.call(null,cljs.core.PersistentArrayMap.EMPTY,cljs.core.map.call(null,(function (p__2229){
var vec__2230 = p__2229;
var k = cljs.core.nth.call(null,vec__2230,(0),null);
var v = cljs.core.nth.call(null,vec__2230,(1),null);
return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [k,org$kp$kpmc$core$enrich_parse_tree_json_$_keywordize_node_tags.call(null,v)], null);
}),node));
} else {
if(cljs.core.sequential_QMARK_.call(null,node)){
return cljs.core.mapv.call(null,org$kp$kpmc$core$enrich_parse_tree_json_$_keywordize_node_tags,node);
} else {
return node;

}
}
}
});
var parse_tree = keywordize_node_tags.call(null,cljs.core.js__GT_clj.call(null,parse_tree_json,new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true));
var companion_guide = cljs.core.js__GT_clj.call(null,companion_guide_json,new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true);
return cljs.core.clj__GT_js.call(null,org.kp.kpmc.enrich.enrich_parse_tree.call(null,parse_tree,companion_guide));
});
org.kp.kpmc.core.run_rule_harness = org.kp.kpmc.companion_rules.run_rule_harness;
org.kp.kpmc.core.normalize_rule_harness_opts = (function org$kp$kpmc$core$normalize_rule_harness_opts(opts){
var o = (function (){var or__5142__auto__ = opts;
if(cljs.core.truth_(or__5142__auto__)){
return or__5142__auto__;
} else {
return cljs.core.PersistentArrayMap.EMPTY;
}
})();
var G__2233 = o;
var G__2233__$1 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"lookupSpecFile","lookupSpecFile",-1361988788)))?cljs.core.assoc.call(null,G__2233,new cljs.core.Keyword(null,"lookup-spec-file","lookup-spec-file",687065480),new cljs.core.Keyword(null,"lookupSpecFile","lookupSpecFile",-1361988788).cljs$core$IFn$_invoke$arity$1(o)):G__2233);
var G__2233__$2 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"includeLookupSql","includeLookupSql",204121854)))?cljs.core.assoc.call(null,G__2233__$1,new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460),new cljs.core.Keyword(null,"includeLookupSql","includeLookupSql",204121854).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$1);
var G__2233__$3 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"includeLookupSql?","includeLookupSql?",1509965706)))?cljs.core.assoc.call(null,G__2233__$2,new cljs.core.Keyword(null,"include-lookup-sql?","include-lookup-sql?",212730460),new cljs.core.Keyword(null,"includeLookupSql?","includeLookupSql?",1509965706).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$2);
var G__2233__$4 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"dbValidation","dbValidation",-1173401578)))?cljs.core.assoc.call(null,G__2233__$3,new cljs.core.Keyword(null,"db-validation?","db-validation?",2032147196),new cljs.core.Keyword(null,"dbValidation","dbValidation",-1173401578).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$3);
var G__2233__$5 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"dbValidation?","dbValidation?",-1221893341)))?cljs.core.assoc.call(null,G__2233__$4,new cljs.core.Keyword(null,"db-validation?","db-validation?",2032147196),new cljs.core.Keyword(null,"dbValidation?","dbValidation?",-1221893341).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$4);
var G__2233__$6 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"envName","envName",-1555267237)))?cljs.core.assoc.call(null,G__2233__$5,new cljs.core.Keyword(null,"env-name","env-name",1998966009),new cljs.core.Keyword(null,"envName","envName",-1555267237).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$5);
var G__2233__$7 = ((cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"subscriberOnlyDbValidation","subscriberOnlyDbValidation",608166416)))?cljs.core.assoc.call(null,G__2233__$6,new cljs.core.Keyword(null,"subscriber-only-db-validation?","subscriber-only-db-validation?",511213543),new cljs.core.Keyword(null,"subscriberOnlyDbValidation","subscriberOnlyDbValidation",608166416).cljs$core$IFn$_invoke$arity$1(o)):G__2233__$6);
if(cljs.core.contains_QMARK_.call(null,o,new cljs.core.Keyword(null,"logMemory","logMemory",36632689))){
return cljs.core.assoc.call(null,G__2233__$7,new cljs.core.Keyword(null,"log-memory?","log-memory?",-916293409),new cljs.core.Keyword(null,"logMemory","logMemory",36632689).cljs$core$IFn$_invoke$arity$1(o));
} else {
return G__2233__$7;
}
});
org.kp.kpmc.core.run_rule_harness_json = (function org$kp$kpmc$core$run_rule_harness_json(companion_csv,edi_file,opts_json){
var opts = org.kp.kpmc.core.normalize_rule_harness_opts.call(null,(((!((opts_json == null))))?cljs.core.js__GT_clj.call(null,opts_json,new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true):cljs.core.PersistentArrayMap.EMPTY));
return cljs.core.clj__GT_js.call(null,org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file,opts));
});
/**
 * One-step API for Node consumers.
 * Returns parsed tree, enriched tree, and validation summary JSON-friendly payload.
 */
org.kp.kpmc.core.parse_enrich_validate_json = (function org$kp$kpmc$core$parse_enrich_validate_json(companion_csv,edi_file,opts_json){
var opts = org.kp.kpmc.core.normalize_rule_harness_opts.call(null,(((!((opts_json == null))))?cljs.core.js__GT_clj.call(null,opts_json,new cljs.core.Keyword(null,"keywordize-keys","keywordize-keys",1310784252),true):cljs.core.PersistentArrayMap.EMPTY));
var harness = org.kp.kpmc.companion_rules.run_rule_harness.call(null,companion_csv,edi_file,opts);
var report = new cljs.core.Keyword(null,"report","report",1394055010).cljs$core$IFn$_invoke$arity$1(harness);
return cljs.core.clj__GT_js.call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"parsed","parsed",-819589156),new cljs.core.Keyword(null,"parsed-tree","parsed-tree",1040023394).cljs$core$IFn$_invoke$arity$1(harness),new cljs.core.Keyword(null,"enriched","enriched",-750799869),new cljs.core.Keyword(null,"annotated-tree","annotated-tree",262346771).cljs$core$IFn$_invoke$arity$1(harness),new cljs.core.Keyword(null,"validation-summary","validation-summary",-1267445308),new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"total","total",1916810418),cljs.core.get_in.call(null,report,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"validation","validation",-2141396518),new cljs.core.Keyword(null,"total","total",1916810418)], null)),new cljs.core.Keyword(null,"passed","passed",-28165278),cljs.core.get_in.call(null,report,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"validation","validation",-2141396518),new cljs.core.Keyword(null,"passed","passed",-28165278)], null)),new cljs.core.Keyword(null,"failed","failed",-1397425762),cljs.core.get_in.call(null,report,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"validation","validation",-2141396518),new cljs.core.Keyword(null,"failed","failed",-1397425762)], null)),new cljs.core.Keyword(null,"lookup","lookup",1225356838),new cljs.core.Keyword(null,"lookup-summary","lookup-summary",1485614183).cljs$core$IFn$_invoke$arity$1(report)], null),new cljs.core.Keyword(null,"report","report",1394055010),report], null));
});
org.kp.kpmc.core.parse_cli_opts = org.kp.kpmc.cli.parse_cli_opts;
org.kp.kpmc.core.cli_usage = org.kp.kpmc.cli.cli_usage;
org.kp.kpmc.core.require_opt = org.kp.kpmc.cli.require_opt;
org.kp.kpmc.core.run_cli_BANG_ = org.kp.kpmc.cli.run_cli_BANG_;
org.kp.kpmc.core._main = (function org$kp$kpmc$core$_main(var_args){
var args__5882__auto__ = [];
var len__5876__auto___2235 = arguments.length;
var i__5877__auto___2236 = (0);
while(true){
if((i__5877__auto___2236 < len__5876__auto___2235)){
args__5882__auto__.push((arguments[i__5877__auto___2236]));

var G__2237 = (i__5877__auto___2236 + (1));
i__5877__auto___2236 = G__2237;
continue;
} else {
}
break;
}

var argseq__5883__auto__ = ((((0) < args__5882__auto__.length))?(new cljs.core.IndexedSeq(args__5882__auto__.slice((0)),(0),null)):null);
return org.kp.kpmc.core._main.cljs$core$IFn$_invoke$arity$variadic(argseq__5883__auto__);
});

(org.kp.kpmc.core._main.cljs$core$IFn$_invoke$arity$variadic = (function (args){
return cljs.core.apply.call(null,org.kp.kpmc.cli._main,args);
}));

(org.kp.kpmc.core._main.cljs$lang$maxFixedArity = (0));

/** @this {Function} */
(org.kp.kpmc.core._main.cljs$lang$applyTo = (function (seq2234){
var self__5862__auto__ = this;
return self__5862__auto__.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq2234));
}));


//# sourceMappingURL=core.js.map
