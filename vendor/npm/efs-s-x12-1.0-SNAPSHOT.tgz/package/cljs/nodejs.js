// Compiled by ClojureScript 1.12.134 {:target :nodejs, :nodejs-rt true, :optimizations :none}
goog.provide('cljs.nodejs');
goog.require('cljs.core');
cljs.nodejs.require = require;
cljs.nodejs.process = process;
cljs.nodejs.enable_util_print_BANG_ = (function cljs$nodejs$enable_util_print_BANG_(){
(cljs.core._STAR_print_newline_STAR_ = false);

cljs.core.set_print_fn_BANG_.call(null,(function() { 
var G__2240__delegate = function (args){
return console.log.apply(console,cljs.core.into_array.call(null,args));
};
var G__2240 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__2241__i = 0, G__2241__a = new Array(arguments.length -  0);
while (G__2241__i < G__2241__a.length) {G__2241__a[G__2241__i] = arguments[G__2241__i + 0]; ++G__2241__i;}
  args = new cljs.core.IndexedSeq(G__2241__a,0,null);
} 
return G__2240__delegate.call(this,args);};
G__2240.cljs$lang$maxFixedArity = 0;
G__2240.cljs$lang$applyTo = (function (arglist__2242){
var args = cljs.core.seq(arglist__2242);
return G__2240__delegate(args);
});
G__2240.cljs$core$IFn$_invoke$arity$variadic = G__2240__delegate;
return G__2240;
})()
);

cljs.core.set_print_err_fn_BANG_.call(null,(function() { 
var G__2243__delegate = function (args){
return console.error.apply(console,cljs.core.into_array.call(null,args));
};
var G__2243 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__2244__i = 0, G__2244__a = new Array(arguments.length -  0);
while (G__2244__i < G__2244__a.length) {G__2244__a[G__2244__i] = arguments[G__2244__i + 0]; ++G__2244__i;}
  args = new cljs.core.IndexedSeq(G__2244__a,0,null);
} 
return G__2243__delegate.call(this,args);};
G__2243.cljs$lang$maxFixedArity = 0;
G__2243.cljs$lang$applyTo = (function (arglist__2245){
var args = cljs.core.seq(arglist__2245);
return G__2243__delegate(args);
});
G__2243.cljs$core$IFn$_invoke$arity$variadic = G__2243__delegate;
return G__2243;
})()
);

return null;
});

//# sourceMappingURL=nodejs.js.map
