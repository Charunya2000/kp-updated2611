﻿const path = require("path");

require(path.join(__dirname, "cljs", "goog", "bootstrap", "nodejs.js"));
require(path.join(__dirname, "cljs", "cljs_deps.js"));

global.CLOSURE_UNCOMPILED_DEFINES = {
  "cljs.core._STAR_target_STAR_": "nodejs"
};

goog.require("org.kp.kpmc.core");

const core = global.org.kp.kpmc.core;
const defaultLookupSpecFile = path.join(__dirname, "save", "companion-db-lookups.edn");

function withLookupSpecDefaults(opts) {
  if (!opts || typeof opts !== "object") {
    return { lookupSpecFile: defaultLookupSpecFile };
  }

  if (opts.lookupSpecFile == null && opts["lookup-spec-file"] == null) {
    return { ...opts, lookupSpecFile: defaultLookupSpecFile };
  }

  return opts;
}

module.exports = {
  core,
  lookupSpecFilePath: defaultLookupSpecFile,
  reverso: core.reverso,
  parseX12Full: core.parse_x12_full_json,
  parseX12Chunked: core.parse_x12_chunked_json,
  parseCompanionGuide: core.parse_companion_guide_json,
  saveCompanionGuideEdn: core.save_companion_guide_edn,
  enrichParseTree: core.enrich_parse_tree_json,
  enrichX12WithCompanionGuide: core.enrich_x12_with_companion_guide,
  runRuleHarness: (companionCsv, ediFile, opts) => core.run_rule_harness_json(companionCsv, ediFile, withLookupSpecDefaults(opts)),
  parseEnrichValidate: (companionCsv, ediFile, opts) => core.parse_enrich_validate_json(companionCsv, ediFile, withLookupSpecDefaults(opts)),
  parseCliOpts: core.parse_cli_opts,
  runCli: core.run_cli_BANG_,
  parseX12FullRaw: core.parse_x12_full,
  parseX12ChunkedRaw: core.parse_x12_chunked,
  parseCompanionGuideRaw: core.parse_companion_guide,
  runRuleHarnessRaw: core.run_rule_harness,
  enrichParseTreeRaw: core.enrich_parse_tree
};
